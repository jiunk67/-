#!/bin/bash
# 自定义加密.sh - Shell脚本加密与自解密工具

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 显示欢迎信息
echo -e "${BLUE}========================================"
echo -e "       Shell 脚本加密与自解密工具"
echo -e "========================================${NC}"
echo -e "${YELLOW}本工具将引导您通过交互式菜单加密 Shell 脚本。"
echo -e "加密后的脚本将在运行时自动解密并执行原始逻辑。"
echo -e "如果未指定加密后脚本的保存路径，默认将保存到 /0/encrypted.sh${NC}"

# 获取原始脚本路径
read -p "请输入要加密的原始脚本路径: " original_script
while [ ! -f "$original_script" ]; do
    echo -e "${RED}错误: 文件不存在或不是普通文件!${NC}"
    read -p "请重新输入要加密的原始脚本路径: " original_script
done

# 获取加密后脚本保存路径
default_output="/0/encrypted.sh"
read -p "请输入加密后脚本的保存路径 (直接回车默认保存到 ${default_output}): " output_path

# 处理输出路径
if [ -z "$output_path" ]; then
    output_path="$default_output"
fi

# 检查输出路径是否是目录
if [ -d "$output_path" ]; then
    echo -e "${RED}错误: 指定的路径是一个目录，请提供具体的文件名!${NC}"
    read -p "请重新输入加密后脚本的保存路径: " output_path
    while [ -z "$output_path" ] || [ -d "$output_path" ]; do
        if [ -z "$output_path" ]; then
            echo -e "${RED}错误: 路径不能为空!${NC}"
        else
            echo -e "${RED}错误: 指定的路径是一个目录，请提供具体的文件名!${NC}"
        fi
        read -p "请重新输入加密后脚本的保存路径: " output_path
    done
fi

# 检查输出目录是否存在，不存在则创建
output_dir=$(dirname "$output_path")
if [ ! -d "$output_dir" ]; then
    mkdir -p "$output_dir" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo -e "${RED}错误: 无法创建输出目录，请检查权限!${NC}"
        exit 1
    fi
fi

# 加密函数
encrypt_script() {
    local input_file=$1
    local output_file=$2
    
    # 读取原始脚本内容
    script_content=$(cat "$input_file")
    
    # 生成随机密钥 (16个字符)
    key=$(head /dev/urandom | tr -dc A-Za-z0-9 | head -c 16)
    
    # 加密脚本内容
    encrypted_content=$(echo "$script_content" | openssl enc -aes-256-cbc -md sha512 -a -pbkdf2 -iter 100000 -pass pass:"$key")
    
    # 生成自解密脚本头部
    header="#!/bin/bash
# 自动生成的自解密脚本
# 原始脚本: $input_file
# 加密时间: $(date)

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo -e \"\${GREEN}正在解密并执行脚本...${NC}\"

# 提取密钥和加密内容
ENCRYPTED_CONTENT=\"$encrypted_content\"
ENCRYPTION_KEY=\"$key\"

# 解密函数
decrypt_and_execute() {
    local encrypted=\$1
    local key=\$2
    
    # 解密内容
    decrypted=\$(echo -e \"\$encrypted\" | openssl enc -d -aes-256-cbc -md sha512 -a -pbkdf2 -iter 100000 -pass pass:\"\$key\" 2>/dev/null)
    
    if [ \$? -ne 0 ]; then
        echo -e \"\${RED}解密失败，请检查密钥或加密内容!${NC}\"
        exit 1
    fi
    
    # 执行解密后的脚本
    eval \"\$decrypted\"
}

# 执行解密
decrypt_and_execute \"\$ENCRYPTED_CONTENT\" \"\$ENCRYPTION_KEY\"
"

    # 写入加密文件
    echo -e "$header" > "$output_file"
    echo -e "ENCRYPTED_CONTENT=\"$encrypted_content\"" >> "$output_file"
    echo -e "ENCRYPTION_KEY=\"$key\"" >> "$output_file"
    chmod +x "$output_file"
    
    echo -e "${GREEN}加密成功! 加密脚本已保存到: $output_file${NC}"
}

# 执行加密
echo -e "[*] 正在加密脚本: $original_script"
encrypt_script "$original_script" "$output_path"

echo -e "${BLUE}========================================"
echo -e "              加密完成!"
echo -e "              加密脚本: $output_path"
echo -e "========================================${NC}"
exit 0
