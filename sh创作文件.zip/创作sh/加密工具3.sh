#!/bin/bash
# 简易Base64工具 - 加密/解密文本或文件

# 检查是否提供了参数
if [ $# -eq 0 ]; then
    echo "简易Base64工具"
    echo "用法: $0 [选项]"
    echo "选项:"
    echo "  -e '文本'       直接加密文本"
    echo "  -d '文本'       直接解密文本"
    echo "  -ef 文件名      加密文件"
    echo "  -df 文件名      解密文件"
    echo "  -et             加密文本(交互式输入)"
    echo "  -dt             解密文本(交互式输入)"
    exit 1
fi

# 加密文本(直接)
if [ "$1" = "-e" ]; then
    if [ -z "$2" ]; then
        echo "错误: 请提供要加密的文本"
        exit 1
    fi
    echo -n "$2" | base64
    echo ""  # 换行
    exit 0
fi

# 解密文本(直接)
if [ "$1" = "-d" ]; then
    if [ -z "$2" ]; then
        echo "错误: 请提供要解密的文本"
        exit 1
    fi
    echo -n "$2" | base64 --decode
    echo ""  # 换行
    exit 0
fi

# 加密文件
if [ "$1" = "-ef" ]; then
    if [ -z "$2" ]; then
        echo "错误: 请提供要加密的文件名"
        exit 1
    fi
    if [ ! -f "$2" ]; then
        echo "错误: 文件 '$2' 不存在"
        exit 1
    fi
    echo "加密中... $2"
    base64 "$2" > "${2}.b64"
    echo "加密完成，结果保存在 ${2}.b64"
    exit 0
fi

# 解密文件
if [ "$1" = "-df" ]; then
    if [ -z "$2" ]; then
        echo "错误: 请提供要解密的文件名"
        exit 1
    fi
    if [ ! -f "$2" ]; then
        echo "错误: 文件 '$2' 不存在"
        exit 1
    fi
    echo "解密中... $2"
    base64 --decode "$2" > "${2%.b64}"
    echo "解密完成，结果保存在 ${2%.b64}"
    exit 0
fi

# 交互式加密文本
if [ "$1" = "-et" ]; then
    echo "请输入要加密的文本(输入完成后按Ctrl+D结束):"
    echo -n "加密结果:"
    base64
    exit 0
fi

# 交互式解密文本
if [ "$1" = "-dt" ]; then
    echo "请输入要解密的文本(输入完成后按Ctrl+D结束):"
    echo -n "解密结果:"
    base64 --decode
    exit 0
fi

# 如果没有匹配的选项，显示帮助
echo "错误: 无效的选项"
echo "请使用: $0 -e '文本'  或  $0 -d '文本'  或  $0 -ef 文件名  或  $0 -df 文件名"
