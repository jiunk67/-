#!/bin/bash
echo ---Mt 管理器---
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
# ======================
# 超级Shell工具箱 v2.0
# 20个有趣功能的集合
# ======================

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 全局变量
VERSION="2.0"
TOOL_NAME="超级Shell工具箱"

# ======================
# 基础函数
# ======================

# 显示横幅
show_banner() {
    clear
    echo -e "${PURPLE}"
    cat << "EOF"
  ____  _             _       _     _           
 |  _ \(_) ___   __ _| | __ _| |__ | | ___  ___ 
 | |_) | |/ _ \ / _` | |/ _` | '_ \| |/ _ \/ __|
 |  _ <| | (_) | (_| | | (_| | |_) | |  __/\__ \
 |_| \_\_|\___/ \__,_|_|\__,_|_.__/|_|\___||___/
EOF
    echo -e "${NC}"
    echo -e "${YELLOW}${TOOL_NAME} v${VERSION}${NC}"
    echo -e "${BLUE}==============================================${NC}"
}

# 显示状态信息
show_status() {
    echo -e "${CYAN}当前时间: ${NC}$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "${CYAN}运行时长: ${NC}$(ps -o etimes= -p $$ | awk '{printf "%02d:%02d:%02d", $1/3600, ($1%3600)/60, $1%60}')"
    echo -e "${BLUE}==============================================${NC}"
}

# 检查依赖
check_dependencies() {
    local deps=("curl" "bc" "awk" "grep" "sed" "jq")
    local missing=()
    
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            missing+=("$dep")
        fi
    done
    
    if [ ${#missing[@]} -gt 0 ]; then
        echo -e "${YELLOW}注意: 以下工具未安装: ${missing[*]}${NC}"
        echo -e "${YELLOW}某些功能可能无法正常工作${NC}"
    fi
}

# ======================
# 功能1-5: 系统工具
# ======================

# 1. 系统信息
system_info() {
    show_banner
    echo -e "${GREEN}=== 系统信息 ===${NC}"
    echo -e "${BLUE}主机名: ${NC}$(hostname)"
    echo -e "${BLUE}操作系统: ${NC}$(lsb_release -d 2>/dev/null | cut -f2- || uname -o)"
    echo -e "${BLUE}内核版本: ${NC}$(uname -r)"
    echo -e "${BLUE}CPU信息: ${NC}$(lscpu | grep 'Model name' | cut -d':' -f2 | sed -e 's/^[ \t]*//' || grep 'model name' /proc/cpuinfo | head -1 | cut -d':' -f2 | sed -e 's/^[ \t]*//')"
    echo -e "${BLUE}CPU核心数: ${NC}$(nproc || grep -c '^processor' /proc/cpuinfo)"
    echo -e "${BLUE}内存使用: ${NC}$(free -h | awk '/Mem:/ {print $3 "/" $2}')"
    echo -e "${BLUE}磁盘使用: ${NC}$(df -h / | awk 'NR==2 {print $3 "/" $2 " (" $5 ")"}')"
    echo -e "${BLUE}系统运行时间: ${NC}$(uptime -p)"
    echo -e "${BLUE}当前用户: ${NC}$(whoami)"
    read -p "按回车键继续..."
}

# 2. 磁盘分析
disk_analyzer() {
    show_banner
    echo -e "${GREEN}=== 磁盘空间分析 ===${NC}"
    echo -e "${BLUE}各分区使用情况:${NC}"
    df -h | awk '{if(NR>1) print $1 " | " $2 " | " $3 " | " $4 " | " $5 " | " $6}'
    echo -e "\n${BLUE}大文件查找 (当前目录下大于100MB的文件):${NC}"
    find . -type f -size +100M -exec ls -lh {} + 2>/dev/null | awk '{print $9 " (" $5 ")"}'
    read -p "按回车键继续..."
}

# 3. 进程管理器
process_manager() {
    show_banner
    echo -e "${GREEN}=== 进程管理器 ===${NC}"
    echo -e "${BLUE}CPU使用率最高的5个进程:${NC}"
    ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -6
    echo -e "\n${BLUE}内存使用率最高的5个进程:${NC}"
    ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head -6
    read -p "按回车键继续..."
}

# 4. 网络诊断
network_diagnostic() {
    show_banner
    echo -e "${GREEN}=== 网络诊断 ===${NC}"
    echo -e "${BLUE}IP地址信息:${NC}"
    ip addr show | grep -E 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | cut -d'/' -f1
    echo -e "\n${BLUE}网络连接状态:${NC}"
    netstat -tulnp 2>/dev/null || ss -tulnp
    echo -e "\n${BLUE}测试网络连通性 (8.8.8.8):${NC}"
    ping -c 4 8.8.8.8 | tail -n 3
    read -p "按回车键继续..."
}

# 5. 系统清理
system_cleaner() {
    show_banner
    echo -e "${GREEN}=== 系统清理工具 ===${NC}"
    echo -e "${YELLOW}以下是可以清理的项目:${NC}"
    echo -e "1. 清理包管理器缓存"
    echo -e "2. 清理临时文件"
    echo -e "3. 清理旧内核"
    echo -e "4. 返回主菜单"
    
    read -p "请选择: " choice
    case $choice in
        1)
            echo -e "${BLUE}清理包管理器缓存...${NC}"
            if command -v apt-get &> /dev/null; then
                sudo apt-get clean
                sudo apt-get autoclean
            elif command -v yum &> /dev/null; then
                sudo yum clean all
            elif command -v dnf &> /dev/null; then
                sudo dnf clean all
            elif command -v pacman &> /dev/null; then
                sudo pacman -Sc
            else
                echo -e "${RED}不支持的包管理器${NC}"
            fi
            ;;
        2)
            echo -e "${BLUE}清理临时文件...${NC}"
            rm -rf /tmp/*
            echo -e "${GREEN}临时文件已清理${NC}"
            ;;
        3)
            echo -e "${BLUE}清理旧内核...${NC}"
            if command -v apt-get &> /dev/null; then
                sudo apt-get autoremove --purge
            else
                echo -e "${YELLOW}此功能需要手动执行${NC}"
            fi
            ;;
        *)
            return
            ;;
    esac
    read -p "按回车键继续..."
}

# ======================
# 功能6-10: 实用工具
# ======================

# 6. 密码生成器
password_generator() {
    show_banner
    echo -e "${GREEN}=== 密码生成器 ===${NC}"
    local length=16
    local include_special=true
    
    read -p "密码长度 (默认16): " input_length
    length=${input_length:-16}
    
    read -p "包含特殊字符? (y/n, 默认y): " special_choice
    if [[ "$special_choice" =~ ^[nN] ]]; then
        include_special=false
    fi
    
    local charset=""
    charset+="abcdefghijklmnopqrstuvwxyz"
    charset+="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    charset+="0123456789"
    
    if [ "$include_special" = true ]; then
        charset+="!@#$%^&*()_+-=[]{}|;:,.<>?"
    fi
    
    echo -e "${BLUE}生成的密码: ${NC}$(tr -dc "$charset" < /dev/urandom | head -c $length)"
    read -p "按回车键继续..."
}

# 7. 文本处理工具
text_processor() {
    show_banner
    echo -e "${GREEN}=== 文本处理工具 ===${NC}"
    echo -e "${BLUE}1. 统计文件行数${NC}"
    echo -e "${BLUE}2. 统计文件单词数${NC}"
    echo -e "${BLUE}3. 统计文件字符数${NC}"
    echo -e "${BLUE}4. 反转文本${NC}"
    echo -e "${BLUE}5. 大小写转换${NC}"
    echo -e "${BLUE}6. 返回主菜单${NC}"
    
    read -p "请选择: " choice
    case $choice in
        1)
            read -p "输入文件路径: " file
            if [ -f "$file" ]; then
                wc -l < "$file"
            else
                echo -e "${RED}文件不存在${NC}"
            fi
            ;;
        2)
            read -p "输入文件路径: " file
            if [ -f "$file" ]; then
                wc -w < "$file"
            else
                echo -e "${RED}文件不存在${NC}"
            fi
            ;;
        3)
            read -p "输入文件路径: " file
            if [ -f "$file" ]; then
                wc -m < "$file"
            else
                echo -e "${RED}文件不存在${NC}"
            fi
            ;;
        4)
            echo -e "${BLUE}输入要反转的文本 (Ctrl+D结束): ${NC}"
            tac
            ;;
        5)
            echo -e "${BLUE}输入文本 (Ctrl+D结束): ${NC}"
            tr '[:upper:][:lower:]' '[:lower:][:upper:]'
            ;;
        *)
            return
            ;;
    esac
    read -p "按回车键继续..."
}

# 8. 文件查找器
file_finder() {
    show_banner
    echo -e "${GREEN}=== 文件查找器 ===${NC}"
    read -p "输入文件名或模式: " pattern
    read -p "输入搜索路径 (默认当前目录): " path
    path=${path:-.}
    
    echo -e "${BLUE}搜索结果:${NC}"
    find "$path" -name "*$pattern*" 2>/dev/null | while read -r file; do
        echo -e "${CYAN}$file${NC}"
    done
    read -p "按回车键继续..."
}

# 9. 计算器
calculator() {
    show_banner
    echo -e "${GREEN}=== 计算器 ===${NC}"
    echo -e "${BLUE}输入数学表达式 (如: 2+2, 5*3, 10/2): ${NC}"
    echo -e "${YELLOW}输入 'quit' 退出计算器${NC}"
    
    while true; do
        read -p "> " expression
        if [ "$expression" = "quit" ]; then
            break
        fi
        result=$(echo "scale=2; $expression" | bc 2>/dev/null)
        if [ -z "$result" ]; then
            echo -e "${RED}无效的表达式${NC}"
        else
            echo -e "${GREEN}结果: $result${NC}"
        fi
    done
    read -p "按回车键继续..."
}

# 10. 颜色测试器
color_tester() {
    show_banner
    echo -e "${GREEN}=== 颜色测试器 ===${NC}"
    echo -e "${BLUE}以下是所有可用颜色:${NC}"
    
    echo -e "${RED}红色文本${NC}"
    echo -e "${GREEN}绿色文本${NC}"
    echo -e "${YELLOW}黄色文本${NC}"
    echo -e "${BLUE}蓝色文本${NC}"
    echo -e "${PURPLE}紫色文本${NC}"
    echo -e "${CYAN}青色文本${NC}"
    echo -e "${NC}默认颜色${NC}"
    
    echo -e "\n${BLUE}背景颜色测试:${NC}"
    echo -e "\033[41m红色背景\033[0m"
    echo -e "\033[42m绿色背景\033[0m"
    echo -e "\033[43m黄色背景\033[0m"
    echo -e "\033[44m蓝色背景\033[0m"
    echo -e "\033[45m紫色背景\033[0m"
    echo -e "\033[46m青色背景\033[0m"
    
    read -p "按回车键继续..."
}

# ======================
# 功能11-15: 娱乐功能
# ======================

# 11. 掷骰子游戏
dice_game() {
    show_banner
    echo -e "${GREEN}=== 掷骰子游戏 ===${NC}"
    echo -e "${BLUE}掷两个六面骰子${NC}"
    
    while true; do
        dice1=$((RANDOM % 6 + 1))
        dice2=$((RANDOM % 6 + 1))
        total=$((dice1 + dice2))
        
        echo -e "${YELLOW}骰子1: $dice1 | 骰子2: $dice2 | 总和: $total${NC}"
        
        if [ $total -eq 12 ]; then
            echo -e "${GREEN}完美！两个6点！${NC}"
        elif [ $total -eq 2 ]; then
            echo -e "${RED}糟糕！两个1点！${NC}"
        elif [ $total -eq 7 ]; then
            echo -e "${BLUE}幸运数字7！${NC}"
        fi
        
        read -p "再次掷骰子? (y/n): " choice
        if [[ "$choice" =~ ^[nN] ]]; then
            break
        fi
    done
    read -p "按回车键继续..."
}

# 12. 猜数字游戏
guess_number() {
    show_banner
    echo -e "${GREEN}=== 猜数字游戏 ===${NC}"
    local number=$((RANDOM % 100 + 1))
    local guess
    local attempts=0
    local max_attempts=7
    
    echo -e "${BLUE}我想了一个1到100之间的数字${NC}"
    echo -e "${BLUE}你有${max_attempts}次机会猜中它！${NC}"
    
    while [ $attempts -lt $max_attempts ]; do
        read -p "第$((attempts+1))次猜测: " guess
        
        if ! [[ "$guess" =~ ^[0-9]+$ ]]; then
            echo -e "${RED}请输入一个数字！${NC}"
            continue
        fi
        
        ((attempts++))
        
        if [ $guess -eq $number ]; then
            echo -e "${GREEN}🎉 恭喜！你用了${attempts}次猜中了数字${number}！${NC}"
            return
        elif [ $guess -lt $number ]; then
            echo -e "${BLUE}太小了！还有$((max_attempts-attempts))次机会${NC}"
        else
            echo -e "${BLUE}太大了！还有$((max_attempts-attempts))次机会${NC}"
        fi
    done
    
    echo -e "${RED}游戏结束！正确答案是${number}${NC}"
    read -p "按回车键继续..."
}

# 13. ASCII艺术生成器
ascii_art() {
    show_banner
    echo -e "${GREEN}=== ASCII艺术生成器 ===${NC}"
    echo -e "${BLUE}选择艺术图案:${NC}"
    echo "1. 猫"
    echo "2. 狗"
    echo "3. 心形"
    echo "4. 星星"
    echo "5. 返回主菜单"
    
    read -p "请选择: " choice
    
    case $choice in
        1)
            cat << "EOF"
 /\_/\  
( o.o ) 
 > ^ <
EOF
            ;;
        2)
            cat << "EOF"
 / \__
(    @\___
 /         O
/   (_____/
/_____/   U
EOF
            ;;
        3)
            cat << "EOF"
  ♥♥♥   ♥♥♥
♥♥♥♥♥ ♥♥♥♥♥
♥♥♥♥♥♥♥♥♥♥♥
 ♥♥♥♥♥♥♥♥♥
  ♥♥♥♥♥♥♥
   ♥♥♥♥♥
    ♥♥♥
     ♥
EOF
            ;;
        4)
            cat << "EOF"
    *
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *
EOF
            ;;
        *)
            return
            ;;
    esac
    read -p "按回车键继续..."
}

# 14. 电影台词生成器
movie_quotes() {
    show_banner
    echo -e "${GREEN}=== 经典电影台词 ===${NC}"
    
    quotes=(
        "\"May the Force be with you.\" - Star Wars"
        "\"I'll be back.\" - The Terminator"
        "\"Here's looking at you, kid.\" - Casablanca"
        "\"Frankly, my dear, I don't give a damn.\" - Gone with the Wind"
        "\"You can't handle the truth!\" - A Few Good Men"
        "\"I see dead people.\" - The Sixth Sense"
        "\"Hasta la vista, baby.\" - The Terminator 2"
        "\"Life is like a box of chocolates...\" - Forrest Gump"
        "\"To infinity and beyond!\" - Toy Story"
        "\"Elementary, my dear Watson.\" - Sherlock Holmes"
    )
    
    random_index=$((RANDOM % ${#quotes[@]}))
    echo -e "${YELLOW}${quotes[$random_index]}${NC}"
    read -p "按回车键继续..."
}

# 15. 心情生成器
mood_generator() {
    show_banner
    echo -e "${GREEN}=== 今日心情生成器 ===${NC}"
    
    moods=(
        "🌟 今天是充满希望的一天！"
        "😊 微笑面对每一天！"
        "🚀 准备好迎接新挑战！"
        "🎵 让音乐带给你快乐！"
        "🌈 生活总是充满惊喜！"
        "💪 你比想象中更强大！"
        "🤗 保持乐观，好事即将发生！"
        "🎨 用创意点亮生活！"
        "🌻 阳光总在风雨后！"
        "🎯 专注于你的目标！"
    )
    
    random_index=$((RANDOM % ${#moods[@]}))
    echo -e "${YELLOW}${moods[$random_index]}${NC}"
    read -p "按回车键继续..."
}

# ======================
# 功能16-20: 高级功能
# ======================

# 16. 系统监控仪表板
system_dashboard() {
    show_banner
    echo -e "${GREEN}=== 系统监控仪表板 ===${NC}"
    echo -e "${BLUE}实时系统状态 (刷新间隔: 2秒)${NC}"
    echo -e "${BLUE}按 Ctrl+C 退出${NC}"
    
    while true; do
        clear
        show_banner
        echo -e "${GREEN}=== 实时系统监控 ===${NC}"
        
        # CPU使用率
        cpu_usage=$(top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1}')
        echo -e "${BLUE}CPU使用率: ${NC}${RED}$(printf "%.1f" $cpu_usage)%${NC}"
        
        # 内存使用率
        mem_total=$(free | grep Mem | awk '{print $2}')
        mem_used=$(free | grep Mem | awk '{print $3}')
        mem_percent=$(echo "scale=1; $mem_used * 100 / $mem_total" | bc)
        echo -e "${BLUE}内存使用率: ${NC}${RED}$(printf "%.1f" $mem_percent)%${NC}"
        
        # 磁盘使用率
        disk_usage=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')
        echo -e "${BLUE}根目录使用率: ${NC}${RED}$disk_usage%${NC}"
        
        # 进程数
        process_count=$(ps -e | wc -l)
        echo -e "${BLUE}运行进程数: ${NC}${PURPLE}$((process_count-1))${NC}"
        
        sleep 2
    done
}

# 17. 网络速度测试
internet_speed() {
    show_banner
    echo -e "${GREEN}=== 网络速度测试 ===${NC}"
    echo -e "${BLUE}正在测试下载速度...${NC}"
    
    if command -v speedtest-cli &> /dev/null; then
        speedtest-cli --simple
    else
        echo -e "${YELLOW}未安装 speedtest-cli，使用备用方法...${NC}"
        echo -e "${BLUE}测试下载速度 (通过 curl)...${NC}"
        start_time=$(date +%s.%N)
        download=$(curl -s -o /dev/null -w '%{size_download}' https://speed.hetzner.de/100MB.bin 2>/dev/null || curl -s -o /dev/null -w '%{size_download}' http://speedtest.tele2.net/100MB.zip 2>/dev/null)
        end_time=$(date +%s.%N)
        time_elapsed=$(echo "$end_time - $start_time" | bc)
        speed_mbps=$(echo "scale=2; ($download / 1048576) / $time_elapsed" | bc)
        echo -e "${GREEN}下载速度: ${NC}${BLUE}$speed_mbps MB/s${NC}"
    fi
    read -p "按回车键继续..."
}

# 18. 文件备份工具
file_backup() {
    show_banner
    echo -e "${GREEN}=== 文件备份工具 ===${NC}"
    read -p "输入要备份的文件或目录路径: " source_path
    read -p "输入备份保存位置 (默认 ~/backups): " backup_dir
    backup_dir=${backup_dir:-~/backups}
    
    if [ ! -e "$source_path" ]; then
        echo -e "${RED}源路径不存在${NC}"
        return
    fi
    
    mkdir -p "$backup_dir"
    timestamp=$(date +%Y%m%d_%H%M%S)
    backup_name=$(basename "$source_path")_$timestamp.tar.gz
    
    echo -e "${BLUE}正在创建备份...${NC}"
    tar -czf "$backup_dir/$backup_name" "$source_path" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}备份成功创建: ${NC}$backup_dir/$backup_name"
    else
        echo -e "${RED}备份失败${NC}"
    fi
    read -p "按回车键继续..."
}

# 19. 批量重命名工具
batch_rename() {
    show_banner
    echo -e "${GREEN}=== 批量重命名工具 ===${NC}"
    read -p "输入目录路径 (默认当前目录): " dir_path
    dir_path=${dir_path:-.}
    read -p "输入原字符串: " old_str
    read -p "输入新字符串: " new_str
    
    if [ ! -d "$dir_path" ]; then
        echo -e "${RED}目录不存在${NC}"
        return
    fi
    
    echo -e "${BLUE}正在重命名文件...${NC}"
    count=0
    for file in "$dir_path"/*"$old_str"*; do
        if [ -e "$file" ]; then
            new_name=$(echo "$file" | sed "s/$old_str/$new_str/g")
            mv "$file" "$new_name"
            echo "重命名: $(basename "$file") -> $(basename "$new_name")"
            ((count++))
        fi
    done
    
    echo -e "${GREEN}完成！重命名了 $count 个文件${NC}"
    read -p "按回车键继续..."
}

# 20. 退出程序
exit_program() {
    show_banner
    echo -e "${GREEN}感谢使用 ${TOOL_NAME}！${NC}"
    echo -e "${YELLOW}版本: ${VERSION}${NC}"
    echo -e "${BLUE}再见！${NC}"
    exit 0
}

# ======================
# 主菜单
# ======================

main_menu() {
    check_dependencies
    
    while true; do
        show_banner
        show_status
        
        echo -e "${GREEN}=== 主菜单 (20个功能) ===${NC}"
        echo "1.  系统信息"
        echo "2.  磁盘分析"
        echo "3.  进程管理器"
        echo "4.  网络诊断"
        echo "5.  系统清理"
        echo "6.  密码生成器"
        echo "7.  文本处理工具"
        echo "8.  文件查找器"
        echo "9.  计算器"
        echo "10. 颜色测试器"
        echo "11. 掷骰子游戏"
        echo "12. 猜数字游戏"
        echo "13. ASCII艺术生成器"
        echo "14. 电影台词生成器"
        echo "15. 心情生成器"
        echo "16. 系统监控仪表板"
        echo "17. 网络速度测试"
        echo "18. 文件备份工具"
        echo "19. 批量重命名工具"
        echo "20. 退出"
        echo -e "${BLUE}========================${NC}"
        
        read -p "请选择功能 (1-20): " choice
        
        case $choice in
            1) system_info ;;
            2) disk_analyzer ;;
            3) process_manager ;;
            4) network_diagnostic ;;
            5) system_cleaner ;;
            6) password_generator ;;
            7) text_processor ;;
            8) file_finder ;;
            9) calculator ;;
            10) color_tester ;;
            11) dice_game ;;
            12) guess_number ;;
            13) ascii_art ;;
            14) movie_quotes ;;
            15) mood_generator ;;
            16) system_dashboard ;;
            17) internet_speed ;;
            18) file_backup ;;
            19) batch_rename ;;
            20) exit_program ;;
            *) 
                echo -e "${RED}无效选项，请输入1-20之间的数字${NC}"
                sleep 2
                ;;
        esac
    done
}

# ======================
# 脚本入口
# ======================

# 检查是否直接运行脚本
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main_menu
fi
