 #!/bin/bash

# =============================================
# 脚本功能：对指定文件进行 Base64 双重加密，
#          并生成一个可执行的嵌套 base64 -d | sh 命令
# 使用方法：./encrypt_file.sh
# =============================================

# 询问用户输入要加密的文件路径
read -p "请输入要加密的文件的完整路径: " file_path

# 检查文件是否存在
if [ ! -f "$file_path" ]; then
    echo "错误：文件 '$file_path' 不存在！"
    exit 1
fi

# 读取文件内容（二进制安全，推荐用 base64 处理任意文件）
file_content=$(base64 -w 0 "$file_path")

if [ -z "$file_content" ]; then
    echo "错误：读取文件内容失败或文件为空！"
    exit 1
fi

echo ""
echo "[*] 原始文件已读取，开始加密..."

# =============================================
# 第一层处理：
#   1. 对文件内容进行 base64 编码（已由上面的 base64 -w 0 完成）
#   2. 在编码结果前加 "echo "（后跟空格），末尾加 " ==| base64 -d | sh"
#   3. 将这个整体字符串再进行一次 base64 编码
# =============================================

# 第一步：构造第一层 payload（编码内容 + 末尾触发器）
layer1_payload="${file_content} ==| base64 -d | sh"

# 第二步：对 layer1_payload 进行 base64 编码（第一层加密）
layer1_encoded=$(echo -n "$layer1_payload" | base64 -w 0)

if [ -z "$layer1_encoded" ]; then
    echo "错误：第一层 Base64 编码失败！"
    exit 1
fi

# 第三步：构造最终命令：
#    echo <layer1_encoded> ==| base64 -d | sh
# 然后再对整个字符串进行 base64 编码，以便安全传输或嵌套
final_payload="echo ${layer1_encoded} ==| base64 -d | sh"

# 第四步：对最终 payload 进行 base64 编码，得到最终可复制的加密字符串
final_encoded=$(echo -n "$final_payload" | base64 -w 0)

if [ -z "$final_encoded" ]; then
    echo "错误：最终 Base64 编码失败！"
    exit 1
fi

# =============================================
# 输出结果
# =============================================

echo ""
echo "✅ 加密完成！"
echo ""
echo "🔐 最终生成的加密命令（Base64 嵌套格式）如下："
echo "--------------------------------------------------"
echo "$final_encoded"
echo "--------------------------------------------------"
echo ""
echo "📌 使用方法：将上面的这一行 base64 字符串复制，然后运行以下命令来还原并执行原文件："
echo "         echo '<上面那行>' | base64 -d | sh"
echo ""
echo "🧠 原理说明："
echo "  1. 该命令会先解码外层 base64，得到："
echo "       echo <layer1_encoded> ==| base64 -d | sh"
echo "  2. 然后执行它，会输出："
echo "       echo <file_base64> ==| base64 -d | sh"
echo "  3. 再执行这一行，最终会执行："
echo "       base64 -d <原文件内容> | sh"
echo "  即：还原并执行你最初的文件内容！"
echo ""
echo "⚠️  安全提醒："
echo "  - 该脚本仅用于学习/授权测试，请勿对不明文件进行加密执行！"
echo "  - 加密后的命令可直接还原并运行原文件内容，具有执行权限！"
echo ""
