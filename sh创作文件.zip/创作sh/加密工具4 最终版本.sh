#!/bin/bash

# 询问加密层数
read -p "请输入加密层数: " layers
if ! [[ "$layers" =~ ^[1-9][0-9]*$ ]]; then
    echo "错误: 层数必须是正整数!"
    exit 1
fi

# 询问文件路径
read -p "请输入要加密的文件路径: " file_path
if [ ! -f "$file_path" ]; then
    echo "错误: 文件不存在!"
    exit 1
fi

# 读取文件内容
content=$(base64 -w0 "$file_path")

# 循环处理指定层数
for ((i=1; i<=$layers; i++)); do
    # 添加前缀和后缀
    content="echo $content ==| base64 -d |sh"
    # 进行Base64编码
    content=$(echo -n "$content" | base64 -w0)
done

# 添加最终前缀和后缀
final_content="echo $content ==| base64 -d |sh"

# 保存到内部存储
output_dir="/storage/emulated/0/"
output_file="$output_dir/multi_encoded_output.txt"
echo "$final_content" > "$output_file"

echo "多层加密完成！"
echo "结果已保存到: $output_file"
