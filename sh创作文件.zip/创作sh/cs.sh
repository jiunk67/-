#!/system/bin/sh
LOG_DIR="/storage/emulated/0/logs"
LOG_FILE="$LOG_DIR/log_$(date +%Y%m%d_%H%M%S).txt" 
LOOP_COUNT=0               
SLEEP_INTERVAL=0

mkdir -p "$LOG_DIR" || {
    echo "❌ 无法创建日志目录 $LOG_DIR，请检查存储权限！"
    exit 1
}


log() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $1" | tee -a "$LOG_FILE"
}


CURRENT_LOOP=1
while true; do

    if [ "$LOOP_COUNT" -gt 0 ] && [ "$CURRENT_LOOP" -gt "$LOOP_COUNT" ]; then
        log "🛑 已达到循环次数限制 ($LOOP_COUNT)，脚本结束。"
        break
    fi

    
    RANDOM_NUM=$((RANDOM % 100))
    STATUS="SUCCESS"
    if [ "$RANDOM_NUM" -lt 20 ]; then  
        STATUS="FAILED"
    fi


    log "🔄 第 $CURRENT_LOOP 次执行 | 状态: $STATUS | 随机数: $RANDOM_NUM"

    
    sleep "$SLEEP_INTERVAL"

    CURRENT_LOOP=$((CURRENT_LOOP + 1))
done


log "✅ 日志已保存至: $LOG_FILE"
echo "📂 日志文件位置: $LOG_FILE"