#!/bin/bash
echo ---Mt 管理器---
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 显示ASCII艺术
show_art() {
    clear
    echo -e "${GREEN}"
    cat << "EOF"
   _____
  / ____|
 | |  __  __ _ _ __ ___   ___ 
 | | |_ |/ _` | '_ ` _ \ / _ \
 | |__| | (_| | | | | | |  __/
  \_____|\__,_|_| |_| |_|\___|
EOF
    echo -e "${NC}"
}

# 显示系统信息
show_system_info() {
    echo -e "${YELLOW}=== 系统信息 ==="
    echo -e "${BLUE}主机名: ${NC}$(hostname)"
    echo -e "${BLUE}操作系统: ${NC}$(lsb_release -d | cut -f2-)"
    echo -e "${BLUE}内核版本: ${NC}$(uname -r)"
    echo -e "${BLUE}CPU信息: ${NC}$(lscpu | grep 'Model name' | cut -d':' -f2 | sed -e 's/^[ \t]*//')"
    echo -e "${BLUE}内存: ${NC}$(free -h | awk '/Mem:/ {print $3 "/" $2}') 使用中"
    echo -e "${BLUE}磁盘使用: ${NC}$(df -h / | awk 'NR==2 {print $3 "/" $2}')"
    echo -e "${YELLOW}===============${NC}"
}

# 动画效果
animate() {
    local frames=(
        "( •_•)"
        "( •_•)>⌐■-■"
        "(⌐■_■)"
    )
    
    for frame in "${frames[@]}"; do
        clear
        show_art
        echo -e "${PURPLE}"
        echo "    $frame"
        echo -e "${NC}"
        show_system_info
        sleep 0.5
    done
}

# 猜数字游戏
guess_number() {
    local number=$((RANDOM % 100 + 1))
    local guess
    local attempts=0
    
    echo -e "${CYAN}我已经想好了一个1到100之间的数字，你能猜出来吗？${NC}"
    
    while true; do
        read -p "你的猜测是: " guess
        ((attempts++))
        
        if [[ $guess -lt $number ]]; then
            echo -e "${BLUE}太小了！再试一次。${NC}"
        elif [[ $guess -gt $number ]]; then
            echo -e "${BLUE}太大了！再试一次。${NC}"
        else
            echo -e "${GREEN}恭喜你！你用了${attempts}次猜中了数字${number}！${NC}"
            break
        fi
    done
}

# 主菜单
main_menu() {
    while true; do
        clear
        show_art
        show_system_info
        
        echo -e "${CYAN}"
        echo "1. 显示动画"
        echo "2. 玩猜数字游戏"
        echo "3. 显示笑话"
        echo "4. 退出"
        echo -e "${NC}"
        
        read -p "请选择 [1-4]: " choice
        
        case $choice in
            1) animate ;;
            2) guess_number ;;
            3) echo -e "${YELLOW}为什么程序员总是分不清万圣节和圣诞节？\n因为 Oct 31 == Dec 25!${NC}" 
               read -p "按回车键继续..." ;;
            4) echo -e "${GREEN}再见！${NC}"
               exit 0 ;;
            *) echo -e "${RED}无效选项，请重试。${NC}"
               sleep 1 ;;
        esac
    done
}

# 检查是否直接运行脚本
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main_menu
fi
