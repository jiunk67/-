#!/bin/bash
echo ---Mt 管理器---
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
# 10个实用Shell脚本功能合集

# 1. 系统信息检查
system_info() {
    echo -e "\n\033[1;34m===== 系统信息 =====\033[0m"
    echo "主机名: $(hostname)"
    echo "操作系统: $(uname -s)"
    echo "内核版本: $(uname -r)"
    echo "系统运行时间: $(uptime -p)"
}

# 2. 磁盘空间检查
disk_space() {
    echo -e "\n\033[1;34m===== 磁盘空间 =====\033[0m"
    df -h | grep -v tmpfs
}

# 3. 内存使用情况
memory_usage() {
    echo -e "\n\033[1;34m===== 内存使用 =====\033[0m"
    free -h
}

# 4. CPU负载检查
cpu_load() {
    echo -e "\n\033[1;34m===== CPU负载 =====\033[0m"
    echo "CPU核心数: $(nproc)"
    uptime
}

# 5. 网络接口信息
network_info() {
    echo -e "\n\033[1;34m===== 网络信息 =====\033[0m"
    ip -br a
}

# 6. 查找大文件
find_large_files() {
    echo -e "\n\033[1;34m===== 查找大文件(>100MB) =====\033[0m"
    find / -type f -size +100M -exec ls -lh {} + 2>/dev/null | awk '{ print $5 ": " $9 }'
}

# 7. 进程资源占用排行
top_processes() {
    echo -e "\n\033[1;34m===== 进程资源占用排行 =====\033[0m"
    echo -e "\033[1;32mCPU使用率TOP5:\033[0m"
    ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 6
    echo -e "\n\033[1;32m内存使用率TOP5:\033[0m"
    ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head -n 6
}

# 8. 检查SSH登录尝试
check_ssh_logins() {
    echo -e "\n\033[1;34m===== SSH登录尝试 =====\033[0m"
    if [ -f "/var/log/auth.log" ]; then
        grep "Failed password" /var/log/auth.log | awk '{print $11}' | sort | uniq -c | sort -nr
    else
        echo "未找到auth.log文件"
    fi
}

# 9. 批量重命名文件
batch_rename() {
    echo -e "\n\033[1;34m===== 批量重命名文件 =====\033[0m"
    read -p "输入文件扩展名(如txt): " ext
    read -p "输入新前缀: " prefix
    count=1
    for file in *.$ext; do
        newname="${prefix}_${count}.${ext}"
        mv "$file" "$newname"
        echo "重命名: $file -> $newname"
        ((count++))
    done
}

# 10. 生成随机密码
generate_password() {
    echo -e "\n\033[1;34m===== 生成随机密码 =====\033[0m"
    openssl rand -base64 12
}

# 显示菜单
show_menu() {
    echo -e "\n\033[1;35m===== 功能菜单 =====\033[0m"
    echo "1. 系统信息检查"
    echo "2. 磁盘空间检查"
    echo "3. 内存使用情况"
    echo "4. CPU负载检查"
    echo "5. 网络接口信息"
    echo "6. 查找大文件"
    echo "7. 进程资源占用排行"
    echo "8. 检查SSH登录尝试"
    echo "9. 批量重命名文件"
    echo "10. 生成随机密码"
    echo -e "\033[1;35m=====================\033[0m"
    echo "0. 退出"
}

# 主循环
while true; do
    show_menu
    read -p "请输入功能编号(1-10): " choice
    
    case $choice in
        1) system_info ;;
        2) disk_space ;;
        3) memory_usage ;;
        4) cpu_load ;;
        5) network_info ;;
        6) find_large_files ;;
        7) top_processes ;;
        8) check_ssh_logins ;;
        9) batch_rename ;;
        10) generate_password ;;
        0) echo "再见！"; exit 0 ;;
        *) echo "无效选择！" ;;
    esac
    
    read -p "按回车键继续..."
done
