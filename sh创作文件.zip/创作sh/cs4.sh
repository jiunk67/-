#!/system/bin/sh
TEST_DIR="/sdcard/StorageTest"      
FILE_SIZE_MB=5000                    
MAX_USAGE_PERCENT=9000                
CLEAN_AFTER_TEST=true              


echo "🔍 检查存储目录: $TEST_DIR"
if [ ! -d "$TEST_DIR" ]; then
    echo "📂 创建测试目录..."
    mkdir -p "$TEST_DIR" || {
        echo "❌ 无法创建目录 $TEST_DIR，请检查存储权限！"
        exit 1
    }
else
    echo "✅ 测试目录已存在: $TEST_DIR"
fi


get_storage_info() {
    df -h "$TEST_DIR" | tail -n 1 | awk '{print $5, $4}'
}


create_test_file() {
    local file_num=$1
    local file_path="$TEST_DIR/testfile_$file_num.dat"
    echo "📦 创建文件: $file_path (${FILE_SIZE_MB}MB)"
    dd if=/dev/zero of="$file_path" bs=1M count=$FILE_SIZE_MB 2>/dev/null || {
        echo "❌ 创建文件失败（可能存储已满）"
        return 1
    }
    echo "✅ 文件创建成功"
}


CURRENT_FILE=1
echo "🚀 开始存储压力测试（按 Ctrl+C 停止）..."
echo "----------------------------------"

while true; do
    
    STORAGE_INFO=$(get_storage_info)
    USED_PERCENT=$(echo "$STORAGE_INFO" | awk '{print $1}' | tr -d '%')
    FREE_SPACE=$(echo "$STORAGE_INFO" | awk '{print $2}')

    echo "📊 当前存储: 已用 ${USED_PERCENT}% | 剩余 $FREE_SPACE"


    if [ "$USED_PERCENT" -ge "$MAX_USAGE_PERCENT" ]; then
        echo "⚠️ 已达到最大占用限制 ${MAX_USAGE_PERCENT}%，停止测试！"
        break
    fi

    
    create_test_file "$CURRENT_FILE" || break

    CURRENT_FILE=$((CURRENT_FILE + 1))
    sleep 0
done


FINAL_STORAGE=$(get_storage_info)
echo "----------------------------------"
echo "🛑 测试结束"
echo "📈 最终存储状态: $FINAL_STORAGE"
echo "📂 测试文件位置: $TEST_DIR/"


if [ "$CLEAN_AFTER_TEST" = true ]; then
    read -p "🗑️ 是否清理测试文件？(y/n): " choice
    if [ "$choice" = "y" ] || [ "$choice" = "Y" ]; then
        echo "🧹 清理测试文件..."
        rm -f "$TEST_DIR"/testfile_*.dat
        echo "✅ 清理完成"
    fi
fi

echo "🎯 脚本执行完毕"
