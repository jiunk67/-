#!/bin/bash
echo ---Mt 管理器---
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ASCII艺术
show_banner() {
    clear
    echo -e "${PURPLE}"
    cat << "EOF"
  _____ _   _ _____  ______ _____  
 |  ___| \ | |_   _| | ___ \  _  | 
 | |__ |  \| | | |   | |_/ / | | | 
 |  __|| . ` | | |   |    /| | | | 
 | |___| |\  |_| |_  | |\ \\ \_/ / 
 \____/\_| \_/\___/  \_| \_|\___/  
EOF
    echo -e "${NC}"
    echo -e "${YELLOW}多功能Shell工具箱 v1.0${NC}"
    echo -e "${BLUE}--------------------------------${NC}"
}

# 系统信息模块
system_info() {
    echo -e "${CYAN}=== 系统信息 ==="
    echo -e "${BLUE}主机名: ${NC}$(hostname)"
    echo -e "${BLUE}操作系统: ${NC}$(lsb_release -d | cut -f2-)"
    echo -e "${BLUE}内核版本: ${NC}$(uname -r)"
    echo -e "${BLUE}CPU信息: ${NC}$(lscpu | grep 'Model name' | cut -d':' -f2 | sed -e 's/^[ \t]*//')"
    echo -e "${BLUE}内存使用: ${NC}$(free -h | awk '/Mem:/ {print $3 "/" $2}')"
    echo -e "${BLUE}磁盘使用: ${NC}$(df -h / | awk 'NR==2 {print $3 "/" $2}')"
    echo -e "${BLUE}系统运行时间: ${NC}$(uptime -p)"
    echo -e "${CYAN}===============${NC}"
}

# 文件搜索器
file_search() {
    read -p "输入要搜索的文件名: " filename
    read -p "输入搜索路径(默认当前目录): " path
    path=${path:-.}
    
    echo -e "${GREEN}正在搜索 '$filename' 在 '$path'...${NC}"
    find "$path" -name "*$filename*" 2>/dev/null | while read -r file; do
        echo -e "${BLUE}找到: ${NC}$file"
    done
}

# 网络工具
network_tools() {
    echo -e "${CYAN}=== 网络工具 ==="
    echo "1. 检查网络连接"
    echo "2. 显示路由表"
    echo "3. 测试网速"
    echo "4. 返回主菜单"
    echo -e "${CYAN}===============${NC}"
    
    read -p "请选择: " choice
    
    case $choice in
        1) ping -c 4 8.8.8.8 ;;
        2) netstat -rn ;;
        3) 
            echo -e "${YELLOW}正在测试下载速度...${NC}"
            curl -s https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py | python3 -
            ;;
        4) return ;;
        *) echo -e "${RED}无效选项${NC}" ;;
    esac
}

# 密码生成器
generate_password() {
    local length=12
    read -p "输入密码长度(默认12): " input_length
    length=${input_length:-12}
    
    echo -e "${GREEN}生成的密码: ${NC}$(tr -dc 'A-Za-z0-9!@#$%^&*()' < /dev/urandom | head -c $length)"
}

# 单位转换器
unit_converter() {
    echo -e "${CYAN}=== 单位转换器 ==="
    echo "1. 摄氏度转华氏度"
    echo "2. 华氏度转摄氏度"
    echo "3. 公里转英里"
    echo "4. 英里转公里"
    echo "5. 返回主菜单"
    echo -e "${CYAN}===============${NC}"
    
    read -p "请选择: " choice
    
    case $choice in
        1)
            read -p "输入摄氏度: " celsius
            echo "华氏度: $(echo "scale=2; $celsius * 9/5 + 32" | bc)"
            ;;
        2)
            read -p "输入华氏度: " fahrenheit
            echo "摄氏度: $(echo "scale=2; ($fahrenheit - 32) * 5/9" | bc)"
            ;;
        3)
            read -p "输入公里: " km
            echo "英里: $(echo "scale=2; $km * 0.621371" | bc)"
            ;;
        4)
            read -p "输入英里: " miles
            echo "公里: $(echo "scale=2; $miles * 1.60934" | bc)"
            ;;
        5) return ;;
        *) echo -e "${RED}无效选项${NC}" ;;
    esac
}

# 小游戏
mini_game() {
    local score=0
    
    echo -e "${PURPLE}=== 数学挑战 ==="
    echo "回答5个简单的数学问题"
    echo -e "准备好了吗？${NC}"
    
    for i in {1..5}; do
        a=$((RANDOM % 10 + 1))
        b=$((RANDOM % 10 + 1))
        op=$((RANDOM % 3))
        
        case $op in
            0) 
                result=$((a + b))
                read -p "$i. $a + $b = " answer
                ;;
            1)
                result=$((a - b))
                read -p "$i. $a - $b = " answer
                ;;
            2)
                result=$((a * b))
                read -p "$i. $a × $b = " answer
                ;;
        esac
        
        if [[ $answer -eq $result ]]; then
            echo -e "${GREEN}正确！${NC}"
            ((score++))
        else
            echo -e "${RED}错误，正确答案是 $result${NC}"
        fi
    done
    
    echo -e "${YELLOW}你的得分: $score/5${NC}"
}

# 主菜单
main_menu() {
    while true; do
        show_banner
        system_info
        
        echo -e "${CYAN}=== 主菜单 ==="
        echo "1. 文件搜索"
        echo "2. 网络工具"
        echo "3. 密码生成器"
        echo "4. 单位转换器"
        echo "5. 数学小游戏"
        echo "6. 退出"
        echo -e "${CYAN}============${NC}"
        
        read -p "请选择: " choice
        
        case $choice in
            1) file_search ;;
            2) network_tools ;;
            3) generate_password ;;
            4) unit_converter ;;
            5) mini_game ;;
            6) 
                echo -e "${GREEN}再见！${NC}"
                exit 0
                ;;
            *) echo -e "${RED}无效选项${NC}" ;;
        esac
        
        read -p "按回车键继续..."
    done
}

# 检查是否直接运行脚本
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main_menu
fi
