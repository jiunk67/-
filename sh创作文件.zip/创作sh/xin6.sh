#!/bin/bash
echo ---Mt 管理器---
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
# 10种加密方式实现脚本
echo -----用扩展包运行-----
echo ---Mt 管理器---
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
echo -----用扩展包运行-----
# 1. AES-256-CBC加密
aes_encrypt() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "用法: aes_encrypt 文件 密码"
        return
    fi
    openssl enc -aes-256-cbc -salt -in "$1" -out "$1.aes" -pass pass:"$2"
    echo "AES加密完成: $1.aes"
}

# 2. AES-256-CBC解密
aes_decrypt() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "用法: aes_decrypt 文件 密码"
        return
    fi
    openssl enc -aes-256-cbc -d -salt -in "$1" -out "${1%.aes}" -pass pass:"$2"
    echo "AES解密完成: ${1%.aes}"
}

# 3. DES加密
des_encrypt() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "用法: des_encrypt 文件 密码"
        return
    fi
    openssl enc -des -salt -in "$1" -out "$1.des" -pass pass:"$2"
    echo "DES加密完成: $1.des"
}

# 4. DES解密
des_decrypt() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "用法: des_decrypt 文件 密码"
        return
    fi
    openssl enc -des -d -salt -in "$1" -out "${1%.des}" -pass pass:"$2"
    echo "DES解密完成: ${1%.des}"
}

# 5. Base64编码
base64_encode() {
    if [ -z "$1" ]; then
        echo "用法: base64_encode 文件"
        return
    fi
    openssl enc -base64 -in "$1" -out "$1.b64"
    echo "Base64编码完成: $1.b64"
}

# 6. Base64解码
base64_decode() {
    if [ -z "$1" ]; then
        echo "用法: base64_decode 文件"
        return
    fi
    openssl enc -base64 -d -in "$1" -out "${1%.b64}"
    echo "Base64解码完成: ${1%.b64}"
}

# 7. RSA非对称加密
rsa_encrypt() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "用法: rsa_encrypt 文件 公钥文件"
        return
    fi
    openssl rsautl -encrypt -inkey "$2" -pubin -in "$1" -out "$1.rsa"
    echo "RSA加密完成: $1.rsa"
}

# 8. RSA非对称解密
rsa_decrypt() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "用法: rsa_decrypt 文件 私钥文件"
        return
    fi
    openssl rsautl -decrypt -inkey "$2" -in "$1" -out "${1%.rsa}"
    echo "RSA解密完成: ${1%.rsa}"
}

# 9. SHA-256哈希
sha256_hash() {
    if [ -z "$1" ]; then
        echo "用法: sha256_hash 文件"
        return
    fi
    sha256sum "$1" | awk '{print $1}' > "$1.sha256"
    echo "SHA-256哈希值已保存到: $1.sha256"
    cat "$1.sha256"
}

# 10. HMAC-SHA1签名
hmac_sign() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "用法: hmac_sign 文件 密钥"
        return
    fi
    openssl dgst -sha1 -hmac "$2" "$1" | awk '{print $2}' > "$1.hmac"
    echo "HMAC-SHA1签名已保存到: $1.hmac"
    cat "$1.hmac"
}

# 生成RSA密钥对
generate_rsa_keys() {
    echo -e "\n生成RSA密钥对..."
    openssl genrsa -out private.pem 2048
    openssl rsa -in private.pem -pubout -out public.pem
    echo "私钥已保存到: private.pem"
    echo "公钥已保存到: public.pem"
}

# 显示菜单
show_menu() {
    echo -e "\n\033[1;35m===== 加密工具菜单 =====\033[0m"
    echo "1. AES-256-CBC加密"
    echo "2. AES-256-CBC解密"
    echo "3. DES加密"
    echo "4. DES解密"
    echo "5. Base64编码"
    echo "6. Base64解码"
    echo "7. RSA加密(需先生成密钥对)"
    echo "8. RSA解密(需先生成密钥对)"
    echo "9. SHA-256哈希"
    echo "10. HMAC-SHA1签名"
    echo "11. 生成RSA密钥对"
    echo -e "\033[1;35m=======================\033[0m"
    echo "0. 退出"
}

# 主循环
while true; do
    show_menu
    read -p "请输入功能编号(1-11): " choice
    
    case $choice in
        1)
            read -p "输入要加密的文件: " file
            read -sp "输入密码: " pass
            echo
            aes_encrypt "$file" "$pass"
            ;;
        2)
            read -p "输入要解密的文件: " file
            read -sp "输入密码: " pass
            echo
            aes_decrypt "$file" "$pass"
            ;;
        3)
            read -p "输入要加密的文件: " file
            read -sp "输入密码: " pass
            echo
            des_encrypt "$file" "$pass"
            ;;
        4)
            read -p "输入要解密的文件: " file
            read -sp "输入密码: " pass
            echo
            des_decrypt "$file" "$pass"
            ;;
        5)
            read -p "输入要编码的文件: " file
            base64_encode "$file"
            ;;
        6)
            read -p "输入要解码的文件: " file
            base64_decode "$file"
            ;;
        7)
            read -p "输入要加密的文件: " file
            read -p "输入公钥文件(默认public.pem): " pubkey
            pubkey=${pubkey:-public.pem}
            rsa_encrypt "$file" "$pubkey"
            ;;
        8)
            read -p "输入要解密的文件: " file
            read -p "输入私钥文件(默认private.pem): " privkey
            privkey=${privkey:-private.pem}
            rsa_decrypt "$file" "$privkey"
            ;;
        9)
            read -p "输入要哈希的文件: " file
            sha256_hash "$file"
            ;;
        10)
            read -p "输入要签名的文件: " file
            read -sp "输入HMAC密钥: " key
            echo
            hmac_sign "$file" "$key"
            ;;
        11)
            generate_rsa_keys
            ;;
        0)
            echo "再见！"
            exit 0
            ;;
        *)
            echo "无效选择！"
            ;;
    esac
    
    read -p "按回车键继续..."
done
