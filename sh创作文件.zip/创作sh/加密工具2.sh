#!/bin/bash
# Base64工具 - 改进版，带有交互模式
# 版本: 2.1
# 新增功能：交互模式、更好的错误处理和持续运行

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 初始化变量
INTERACTIVE=false

# 显示帮助信息
show_help() {
    echo -e "${GREEN}Base64工具 - 加密/解密文件和文本${NC}"
    echo "用法: $0 [选项]"
    echo "选项:"
    echo -e "  ${YELLOW}-i, --interactive${NC}  进入交互模式"
    echo -e "  ${YELLOW}-e, --encode${NC}      加密文本或文件"
    echo -e "  ${YELLOW}-d, --decode${NC}      解密文本或文件"
    echo -e "  ${YELLOW}-f, --file${NC}        指定要处理的文件"
    echo -e "  ${YELLOW}-o, --output${NC}      指定输出文件(默认: 输出到屏幕)"
    echo -e "  ${YELLOW}-t, --text${NC}        直接提供要处理的文本"
    echo -e "  ${YELLOW}-h, --help${NC}        显示此帮助信息"
    echo ""
    echo -e "${YELLOW}交互模式:${NC}"
    echo "  在交互模式下，您可以连续执行多种操作而无需重新启动脚本"
    echo ""
    echo -e "${YELLOW}示例:${NC}"
    echo "  加密文本: $0 -e -t '要加密的文本'"
    echo "  加密文件: $0 -e -f input.txt -o output.b64"
    echo "  解密文本: $0 -d -t '加密后的文本'"
    echo "  解密文件: $0 -d -f encoded.b64 -o decoded.txt"
    echo "  交互模式: $0 -i"
}

# 检查依赖
check_dependencies() {
    if ! command -v base64 &> /dev/null; then
        echo -e "${RED}错误: 此脚本需要base64命令，但未安装。${NC}"
        exit 1
    fi
}

# 加密文本
encrypt_text() {
    local text="$1"
    echo -e "${GREEN}加密结果:${NC}"
    echo -n "$text" | base64
    echo ""
}

# 解密文本
decrypt_text() {
    local text="$1"
    echo -e "${GREEN}解密结果:${NC}"
    echo -n "$text" | base64 --decode
    echo ""
}

# 加密文件
encrypt_file() {
    local input_file="$1"
    local output_file="${2:-${input_file}.b64}"
    
    if [ ! -f "$input_file" ]; then
        echo -e "${RED}错误: 输入文件不存在: $input_file${NC}"
        return 1
    fi
    
    echo -e "${GREEN}正在加密文件: $input_file ...${NC}"
    base64 "$input_file" > "$output_file"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}文件加密成功! 已保存到: $output_file${NC}"
        echo -e "${YELLOW}文件大小: ${GREEN}$(du -h "$output_file" | cut -f1)${NC}"
        return 0
    else
        echo -e "${RED}文件加密失败${NC}"
        return 1
    fi
}

# 解密文件
decrypt_file() {
    local input_file="$1"
    local output_file="${2:-${input_file%.b64}}"
    
    if [ ! -f "$input_file" ]; then
        echo -e "${RED}错误: 输入文件不存在: $input_file${NC}"
        return 1
    fi
    
    echo -e "${GREEN}正在解密文件: $input_file ...${NC}"
    base64 --decode "$input_file" > "$output_file"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}文件解密成功! 已保存到: $output_file${NC}"
        echo -e "${YELLOW}文件大小: ${GREEN}$(du -h "$output_file" | cut -f1)${NC}"
        return 0
    else
        echo -e "${RED}文件解密失败${NC}"
        return 1
    fi
}

# 交互模式
interactive_mode() {
    echo -e "${CYAN}\n=== 进入Base64工具交互模式 ===${NC}"
    echo -e "${CYAN}输入 'help' 查看可用命令，'exit' 退出交互模式${NC}\n"
    
    while true; do
        read -p $'\033[1;36mBase64>\033[0m ' user_input
        
        case "$user_input" in
            exit|quit)
                echo -e "${GREEN}退出交互模式。${NC}"
                break
                ;;
            help|h)
                echo -e "${YELLOW}可用命令:${NC}"
                echo -e "  ${CYAN}encode${NC} - 加密文本或文件"
                echo -e "  ${CYAN}decode${NC} - 解密文本或文件"
                echo -e "  ${CYAN}help${NC}   - 显示帮助信息"
                echo -e "  ${CYAN}exit${NC}   - 退出交互模式"
                echo ""
                echo -e "${YELLOW}加密/解密参数:${NC}"
                echo -e "  -t '文本'   : 直接处理文本"
                echo -e "  -f 文件名   : 处理文件"
                echo -e "  -o 输出文件 : 指定输出文件(仅对文件有效)"
                echo ""
                continue
                ;;
            *)
                # 处理命令
                if [[ "$user_input" == encode* ]]; then
                    action="encode"
                elif [[ "$user_input" == decode* ]]; then
                    action="decode"
                else
                    echo -e "${RED}无效命令。输入 'help' 查看可用命令。${NC}"
                    continue
                fi
                
                # 解析参数
                local params="${user_input#*$action }"
                local input_type=""
                local input_value=""
                local output_file=""
                
                # 解析参数
                while [[ "$params" =~ (-[a-zA-Z]) ]]; do
                    local opt="${BASH_REMATCH[0]}"
                    params="${params#*$opt}"
                    
                    case "$opt" in
                        -t)
                            input_type="text"
                            input_value="${params%% *}"
                            params="${params#*$input_value}"
                            ;;
                        -f)
                            input_type="file"
                            input_value="${params%% *}"
                            params="${params#*$input_value}"
                            ;;
                        -o)
                            output_file="${params%% *}"
                            params="${params#*$output_file}"
                            ;;
                    esac
                done
                
                # 执行操作
                if [ "$action" == "encode" ]; then
                    if [ -n "$input_value" ]; then
                        if [ "$input_type" == "text" ]; then
                            encrypt_text "$input_value"
                        elif [ "$input_type" == "file" ] && [ -f "$input_value" ]; then
                            encrypt_file "$input_value" "$output_file"
                        else
                            echo -e "${RED}错误: 文件不存在或无效${NC}"
                        fi
                    else
                        echo -e "${RED}错误: 缺少参数。使用 -t 或 -f 指定输入${NC}"
                    fi
                elif [ "$action" == "decode" ]; then
                    if [ -n "$input_value" ]; then
                        if [ "$input_type" == "text" ]; then
                            decrypt_text "$input_value"
                        elif [ "$input_type" == "file" ] && [ -f "$input_value" ]; then
                            decrypt_file "$input_value" "$output_file"
                        else
                            echo -e "${RED}错误: 文件不存在或无效${NC}"
                        fi
                    else
                        echo -e "${RED}错误: 缺少参数。使用 -t 或 -f 指定输入${NC}"
                    fi
                fi
                ;;
        esac
    done
}

# 主函数
main() {
    check_dependencies
    
    # 如果没有参数，进入交互模式
    if [ $# -eq 0 ]; then
        INTERACTIVE=true
    fi
    
    # 解析参数
    while [[ "$#" -gt 0 ]]; do
        case $1 in
            -i|--interactive)
                INTERACTIVE=true
                shift ;;
            -e|--encode)
                ACTION="encode"
                shift ;;
            -d|--decode)
                ACTION="decode"
                shift ;;
            -f|--file)
                INPUT_FILE="$2"
                shift 2 ;;
            -o|--output)
                OUTPUT_FILE="$2"
                shift 2 ;;
            -t|--text)
                TEXT_TO_PROCESS="$2"
                shift 2 ;;
            -h|--help)
                show_help
                exit 0 ;;
            *) echo -e "${RED}未知参数: $1${NC}"; show_help; exit 1 ;;
        esac
    done
    
    # 执行操作
    if $INTERACTIVE; then
        interactive_mode
    else
        case "$ACTION" in
            encode)
                if [ -n "$INPUT_FILE" ]; then
                    encrypt_file "$INPUT_FILE" "$OUTPUT_FILE"
                elif [ -n "$TEXT_TO_PROCESS" ]; then
                    encrypt_text "$TEXT_TO_PROCESS"
                else
                    echo -e "${RED}错误: 加密操作需要指定文本(-t)或文件(-f)${NC}"
                    show_help
                    exit 1
                fi
                ;;
            decode)
                if [ -n "$INPUT_FILE" ]; then
                    decrypt_file "$INPUT_FILE" "$OUTPUT_FILE"
                elif [ -n "$TEXT_TO_PROCESS" ]; then
                    decrypt_text "$TEXT_TO_PROCESS"
                else
                    echo -e "${RED}错误: 解密操作需要指定文本(-t)或文件(-f)${NC}"
                    show_help
                    exit 1
                fi
                ;;
            *)
                echo -e "${RED}错误: 未指定操作类型${NC}"
                show_help
                exit 1
                ;;
        esac
        
        # 防止脚本立即退出（如果从其他脚本调用）
        if [ -z "$KEEP_RUNNING" ]; then
            echo -e "\n${GREEN}操作完成。按Enter键退出...${NC}"
            read -r
        fi
    fi
}

# 执行主函数
main "$@"
