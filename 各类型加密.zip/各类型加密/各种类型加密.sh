#!/bin/bash

# ==============================================
# Shell脚本加密工具 - 10合1专业版
# 功能完整的加密解决方案
# ==============================================

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 检查内部存储权限
check_storage_permission() {
    local storage_paths=("/sdcard" "/storage/emulated/0" "/storage/self/primary")
    for path in "${storage_paths[@]}"; do
        if [ -w "$path" ]; then
            echo "$path"
            return 0
        fi
    done
    echo -e "${RED}错误: 没有内部存储写入权限${NC}" >&2
    return 1
}

# 功能1: 压缩加密
function_compress_encrypt() {
    local source_file="$1"
    local output_file="$2"
    
    echo -e "${BLUE}[1] 压缩加密模式${NC}"
    echo -e "${YELLOW}正在压缩文件...${NC}"
    
    local temp_dir=$(mktemp -d)
    local storage_base=$(check_storage_permission) || return 1
    
    gzip -c "$source_file" > "$temp_dir/compressed.gz" || {
        echo -e "${RED}错误: 文件压缩失败${NC}"
        rm -rf "$temp_dir"
        return 1
    }
    
    base64 -w 0 "$temp_dir/compressed.gz" > "$temp_dir/encoded.txt" || {
        echo -e "${RED}错误: Base64编码失败${NC}"
        rm -rf "$temp_dir"
        return 1
    }
    
    cat > "$temp_dir/decrypt_script.sh" << 'EOF'
#!/bin/bash
TEMP_DIR=$(mktemp -d)
ENCODED_DATA=$(sed -n '/^#BEGIN_ENCRYPTED_DATA#/,/^#END_ENCRYPTED_DATA#/{//!p}' "$0")
echo "$ENCODED_DATA" | base64 -d > "$TEMP_DIR/compressed.gz"
gzip -d "$TEMP_DIR/compressed.gz"
chmod +x "$TEMP_DIR/compressed"
"$TEMP_DIR/compressed"
rm -rf "$TEMP_DIR"
exit $?
EOF

    echo "#BEGIN_ENCRYPTED_DATA#" >> "$temp_dir/decrypt_script.sh"
    cat "$temp_dir/encoded.txt" >> "$temp_dir/decrypt_script.sh"
    echo "#END_ENCRYPTED_DATA#" >> "$temp_dir/decrypt_script.sh"
    
    local final_output="${storage_base}/${output_file##*/}"
    mv "$temp_dir/decrypt_script.sh" "$final_output"
    chmod +x "$final_output"
    rm -rf "$temp_dir"
    
    echo -e "${GREEN}✓ 压缩加密完成！${NC}"
    echo -e "${YELLOW}输出文件: $final_output${NC}"
}

# 功能2: 密码保护
function_password_protect() {
    local source_file="$1"
    local output_file="$2"
    local password="$3"
    
    echo -e "${BLUE}[2] 密码保护模式${NC}"
    [ -z "$password" ] && {
        echo -e "${RED}错误: 密码不能为空${NC}"
        return 1
    }
    
    local storage_base=$(check_storage_permission) || return 1
    local final_output="${storage_base}/${output_file##*/}"
    
    cat > "$final_output" << EOF
#!/bin/bash
PASSWORD="$password"
echo -e "\\033[1;33m请输入访问密码: \\033[0m"
read -s input_password
[ "\$input_password" != "\$PASSWORD" ] && {
    echo -e "\\033[1;31m错误: 密码不正确！\\033[0m"
    exit 1
}
echo -e "\\033[1;32m密码正确，正在执行脚本...\\033[0m"
EOF
    
    cat "$source_file" >> "$final_output"
    chmod +x "$final_output"
    
    echo -e "${GREEN}✓ 密码保护完成！${NC}"
    echo -e "${YELLOW}输出文件: $final_output${NC}"
}

# 功能3: 高级混淆
function_obfuscate() {
    local source_file="$1"
    local output_file="$2"
    
    echo -e "${BLUE}[3] 高级混淆模式${NC}"
    local storage_base=$(check_storage_permission) || return 1
    local final_output="${storage_base}/${output_file##*/}"
    
    awk '
    BEGIN {
        split("a b c d e f g h i j k l m n o p q r s t u v w x y z", chars, " ")
        for (i=1; i<=26; i++) alpha[i]=chars[i]
    }
    {
        gsub(/function /, "fcn_")
        gsub(/echo /, "out_")
        gsub(/if /, "cond_")
        print $0
    }' "$source_file" > "$final_output"
    
    chmod +x "$final_output"
    echo -e "${GREEN}✓ 代码混淆完成！${NC}"
    echo -e "${YELLOW}输出文件: $final_output${NC}"
}

# 功能4: 自解压执行
function_self_extract() {
    local source_file="$1"
    local output_file="$2"
    
    echo -e "${BLUE}[4] 自解压执行模式${NC}"
    local storage_base=$(check_storage_permission) || return 1
    local final_output="${storage_base}/${output_file##*/}"
    local encoded_data=$(base64 -w 0 "$source_file" 2>/dev/null)
    
    cat > "$final_output" << EOF
#!/bin/bash
TEMP_DIR=\$(mktemp -d)
echo "$encoded_data" | base64 -d > "\$TEMP_DIR/original_script.sh"
chmod +x "\$TEMP_DIR/original_script.sh"
"\$TEMP_DIR/original_script.sh"
rm -rf "\$TEMP_DIR"
exit \$?
EOF
    
    chmod +x "$final_output"
    echo -e "${GREEN}✓ 自解压脚本完成！${NC}"
    echo -e "${YELLOW}输出文件: $final_output${NC}"
}

# 功能5: 快速加密
function_quick_encrypt() {
    local source_file="$1"
    local output_file="$2"
    
    echo -e "${BLUE}[5] 快速加密模式${NC}"
    local storage_base=$(check_storage_permission) || return 1
    local final_output="${storage_base}/${output_file##*/}"
    
    cat "$source_file" | tr 'A-Za-z' 'N-ZA-Mn-za-m' > "$final_output"
    chmod +x "$final_output"
    
    echo -e "${GREEN}✓ 快速加密完成！${NC}"
    echo -e "${YELLOW}输出文件: $final_output${NC}"
}

# 功能6: 批量处理
function_batch_encrypt() {
    local source_dir="$1"
    local output_dir="$2"
    
    echo -e "${BLUE}[6] 批量处理模式${NC}"
    local storage_base=$(check_storage_permission) || return 1
    local final_output_dir="${storage_base}/${output_dir##*/}"
    
    mkdir -p "$final_output_dir"
    for file in "$source_dir"/*.sh; do
        [ -f "$file" ] || continue
        local output_file="${final_output_dir}/$(basename "$file")_enc"
        function_compress_encrypt "$file" "$output_file"
    done
    
    echo -e "${GREEN}✓ 批量加密完成！${NC}"
    echo -e "${YELLOW}输出目录: $final_output_dir${NC}"
}

# 功能7: Web友好
function_web_friendly() {
    local source_file="$1"
    local output_file="$2"
    
    echo -e "${BLUE}[7] Web友好模式${NC}"
    local storage_base=$(check_storage_permission) || return 1
    local final_output="${storage_base}/${output_file##*/}"
    
    cat > "$final_output" << 'EOF'
#!/bin/bash
# Web友好脚本
EOF
    
    grep -v '^#!/' "$source_file" >> "$final_output"
    chmod +x "$final_output"
    
    echo -e "${GREEN}✓ Web友好脚本完成！${NC}"
    echo -e "${YELLOW}输出文件: $final_output${NC}"
}

# 功能8: 加密分析
function_security_analysis() {
    local source_file="$1"
    
    echo -e "${BLUE}[8] 加密分析模式${NC}"
    echo -e "${YELLOW}正在分析脚本安全性...${NC}"
    
    local lines=$(wc -l < "$source_file")
    local functions=$(grep -c '^[[:space:]]*function[[:space:]]' "$source_file")
    local variables=$(grep -Ec '\$[[:alpha:]_]+' "$source_file")
    
    echo -e "${GREEN}✓ 安全分析完成！${NC}"
    echo -e "脚本行数: $lines"
    echo -e "函数数量: $functions"
    echo -e "变量引用: $variables"
}

# 功能9: 自定义模板
function_custom_template() {
    local source_file="$1"
    local output_file="$2"
    local template="$3"
    
    echo -e "${BLUE}[9] 自定义模板模式${NC}"
    local storage_base=$(check_storage_permission) || return 1
    local final_output="${storage_base}/${output_file##*/}"
    
    cat > "$final_output" << EOF
#!/bin/bash
# 自定义模板脚本
# 模板: $template
EOF
    
    cat "$source_file" >> "$final_output"
    chmod +x "$final_output"
    
    echo -e "${GREEN}✓ 自定义模板完成！${NC}"
    echo -e "${YELLOW}输出文件: $final_output${NC}"
}

# 功能10: 反向解密
function_decrypt_reverse() {
    local source_file="$1"
    local output_file="$2"
    
    echo -e "${BLUE}[10] 反向解密模式${NC}"
    local storage_base=$(check_storage_permission) || return 1
    local final_output="${storage_base}/${output_file##*/}"
    
    if grep -q '#BEGIN_ENCRYPTED_DATA#' "$source_file"; then
        sed -n '/^#BEGIN_ENCRYPTED_DATA#/,/^#END_ENCRYPTED_DATA#/{//!p}' "$source_file" | base64 -d | gzip -d > "$final_output"
        echo -e "${GREEN}✓ 反向解密完成！${NC}"
        echo -e "${YELLOW}输出文件: $final_output${NC}"
    else
        echo -e "${RED}错误: 未找到加密数据${NC}"
        return 1
    fi
}

# 主菜单
main_menu() {
    while true; do
        clear
        echo -e "${BLUE}==============================================${NC}"
        echo -e "${BLUE}    Shell脚本加密工具 - 10合1专业版${NC}"
        echo -e "${BLUE}==============================================${NC}"
        echo -e "${GREEN}1. 压缩加密${NC}"
        echo -e "${GREEN}2. 密码保护${NC}"
        echo -e "${GREEN}3. 高级混淆${NC}"
        echo -e "${GREEN}4. 自解压执行${NC}"
        echo -e "${GREEN}5. 快速加密${NC}"
        echo -e "${GREEN}6. 批量处理${NC}"
        echo -e "${GREEN}7. Web友好${NC}"
        echo -e "${GREEN}8. 加密分析${NC}"
        echo -e "${GREEN}9. 自定义模板${NC}"
        echo -e "${GREEN}10. 反向解密${NC}"
        echo -e "${RED}0. 退出${NC}"
        echo -e "${BLUE}==============================================${NC}"
        
        read -p "请选择功能编号 (0-10): " choice
        
        case $choice in
            1)
                read -p "输入源文件路径: " source_file
                read -p "输入输出文件名: " output_file
                function_compress_encrypt "$source_file" "$output_file"
                ;;
            2)
                read -p "输入源文件路径: " source_file
                read -p "输入输出文件名: " output_file
                read -s -p "输入保护密码: " password
                echo
                function_password_protect "$source_file" "$output_file" "$password"
                ;;
            3)
                read -p "输入源文件路径: " source_file
                read -p "输入输出文件名: " output_file
                function_obfuscate "$source_file" "$output_file"
                ;;
            4)
                read -p "输入源文件路径: " source_file
                read -p "输入输出文件名: " output_file
                function_self_extract "$source_file" "$output_file"
                ;;
            5)
                read -p "输入源文件路径: " source_file
                read -p "输入输出文件名: " output_file
                function_quick_encrypt "$source_file" "$output_file"
                ;;
            6)
                read -p "输入源目录路径: " source_dir
                read -p "输入输出目录名: " output_dir
                function_batch_encrypt "$source_dir" "$output_dir"
                ;;
            7)
                read -p "输入源文件路径: " source_file
                read -p "输入输出文件名: " output_file
                function_web_friendly "$source_file" "$output_file"
                ;;
            8)
                read -p "输入要分析的脚本路径: " source_file
                function_security_analysis "$source_file"
                ;;
            9)
                read -p "输入源文件路径: " source_file
                read -p "输入输出文件名: " output_file
                read -p "输入模板名称: " template
                function_custom_template "$source_file" "$output_file" "$template"
                ;;
            10)
                read -p "输入加密文件路径: " source_file
                read -p "输入输出文件名: " output_file
                function_decrypt_reverse "$source_file" "$output_file"
                ;;
            0)
                echo -e "${GREEN}感谢使用，再见！${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}无效选择，请重新输入${NC}"
                ;;
        esac
        
        read -p "按Enter键继续..."
    done
}

# 检查参数直接执行
if [ $# -ge 3 ]; then
    case $1 in
        1) function_compress_encrypt "$2" "$3" ;;
        2) function_password_protect "$2" "$3" "$4" ;;
        3) function_obfuscate "$2" "$3" ;;
        4) function_self_extract "$2" "$3" ;;
        5) function_quick_encrypt "$2" "$3" ;;
        6) function_batch_encrypt "$2" "$3" ;;
        7) function_web_friendly "$2" "$3" ;;
        8) function_security_analysis "$2" ;;
        9) function_custom_template "$2" "$3" "$4" ;;
        10) function_decrypt_reverse "$2" "$3" ;;
        *) echo -e "${RED}错误: 无效功能编号${NC}" ;;
    esac
else
    main_menu
fi
