

#!/bin/bash

# =============================================
# script_encryptor.sh —— 一个自包含的 Shell 脚本加密工具
#
# 功能：交互式地让你选择一个脚本，设置密码，然后生成一个受密码保护的脚本。
# 加密方式：使用 openssl AES-256-CBC + Base64，运行时需输入密码解密执行。
# =============================================

# 检查是否安装了 openssl
if ! command -v openssl &> /dev/null; then
    echo "❌ 错误：未检测到 openssl，请先安装 openssl。"
    echo "   - Ubuntu/Debian: sudo apt install openssl"
    echo "   - CentOS/RHEL: sudo yum install openssl"
    echo "   - macOS: 一般已预装"
    exit 1
fi

# 欢迎信息
echo "=============================================="
echo "    🛡️  Shell 脚本加密工具 (自包含版) "
echo "    🔐 输入脚本路径、密码，生成受保护的脚本"
echo "=============================================="

# --------------------------
# 交互式获取用户输入
# --------------------------

# 目标脚本
read -p "📂 请输入你要加密的脚本路径（如 ./myscript.sh）: " TARGET_SCRIPT

# 检查目标脚本是否存在
if [ ! -f "$TARGET_SCRIPT" ]; then
    echo "❌ 错误：文件 '$TARGET_SCRIPT' 不存在."
    exit 1
fi

# 检查是否是 shell 脚本（可选，非强制）
if [[ ! "$TARGET_SCRIPT" =~ \.sh$ ]] && [[ ! "$TARGET_SCRIPT" =~ \.bash$ ]]; then
    read -p "⚠️  文件 '$TARGET_SCRIPT' 似乎不是 .sh 或 .bash 脚本，确定要加密吗？(y/N): " CONFIRM
    if [[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]]; then
        echo "❌ 用户取消操作."
        exit 0
    fi
fi

# 设置密码
read -s -p "🔑 请输入加密密码: " PASSWORD
echo ""
read -s -p "🔑 请再次输入密码确认: " PASSWORD_CONFIRM
echo ""

if [ "$PASSWORD" != "$PASSWORD_CONFIRM" ]; then
    echo "❌ 两次输入的密码不一致，退出."
    exit 1
fi

# 输出文件名
read -p "📤 请输入加密后输出的脚本文件名（如 ./myscript_protected.sh）: " OUTPUT_SCRIPT

# 检查输出文件是否已存在
if [ -f "$OUTPUT_SCRIPT" ]; then
    read -p "⚠️  文件 '$OUTPUT_SCRIPT' 已存在，是否覆盖？(y/N): " OVERWRITE
    if [[ "$OVERWRITE" != "y" && "$OVERWRITE" != "Y" ]]; then
        echo "❌ 用户取消操作."
        exit 0
    fi
fi

# =========================
# 加密逻辑开始
# =========================

echo "🔒 正在加密脚本内容..."

# 使用 openssl 加密脚本内容，输出 base64
ENCRYPTED_PAYLOAD=$(openssl enc -aes-256-cbc -salt -in "$TARGET_SCRIPT" -pass pass:"$PASSWORD" 2>/dev/null | base64)

if [ -z "$ENCRYPTED_PAYLOAD" ]; then
    echo "❌ 加密失败，请检查密码或文件内容."
    exit 1
fi

# =========================
# 生成受密码保护的脚本
# =========================

cat > "$OUTPUT_SCRIPT" <<EOF
#!/bin/bash

# ============================================
# 🛡️  这是一个由脚本加密工具生成的受密码保护的脚本
#     🔐 只有输入正确密码才能运行原始脚本内容
# ============================================

# 预设的密码（已嵌入，注意保密！）
PASSWORD="$PASSWORD"

# 提示用户输入密码
echo -n "🔐 请输入密码以运行此脚本: "
read -s USER_INPUT
echo ""

if [ "\$USER_INPUT" != "\$PASSWORD" ]; then
    echo "❌ 密码错误，退出."
    exit 1
fi

# Base64 格式的加密内容
ENCRYPTED_PAYLOAD=\$(cat <<'ENCRYPTED_DATA'
$ENCRYPTED_PAYLOAD
ENCRYPTED_DATA
)

# 解密过程
DECRYPTED_SCRIPT=\$(echo "\$ENCRYPTED_PAYLOAD" | base64 --decode | openssl enc -d -aes-256-cbc -salt -pass pass:"\$PASSWORD" 2>/dev/null)

if [ -z "\$DECRYPTED_SCRIPT" ]; then
    echo "❌ 解密失败，可能是密码错误或脚本已损坏."
    exit 1
fi

# 执行解密后的脚本内容
echo "\$DECRYPTED_SCRIPT" | bash
EOF

# 添加可执行权限
chmod +x "$OUTPUT_SCRIPT"

# =========================
# 完成提示
# =========================

echo ""
echo "✅ 加密完成！"
echo "🔐 原始脚本: $TARGET_SCRIPT"
echo "🔒 加密脚本: $OUTPUT_SCRIPT"
echo "🔑 加密密码: $PASSWORD （请妥善保管，建议不要共享此密码）"
echo "📌 提示：运行加密脚本时，会要求输入密码，例如："
echo "         \$ ./$OUTPUT_SCRIPT"
echo "=============================================="
