#!/bin/sh

# 文件转二进制字符串工具

# 默认保存路径（当前目录下的binary_output.txt）
DEFAULT_OUTPUT_PATH="$PWD/binary_output.txt"

# 检查是否安装了zenity
if ! command -v zenity >/dev/null 2>&1; then
    echo "/storage/emulated/0/加密工具.sh: line 137: 未检测到 zenity，将使用命令行手动输入文件路径"
fi

# 使用zenity选择文件或手动输入文件路径
if command -v zenity >/dev/null 2>&1; then
    FILE_PATH=$(zenity --file-selection --title="请选择要转换的文件" 2>/dev/null)
    if [ $? -ne 0 ] || [ -z "$FILE_PATH" ]; then
        echo "未选择文件，请手动输入文件路径:"
        read FILE_PATH
    fi
else
    echo "请输入文件路径:"
    read FILE_PATH
fi

# 检查文件是否存在
if [ ! -f "$FILE_PATH" ]; then
    echo "错误：文件不存在: $FILE_PATH"
    exit 1
fi

echo "[✓] 文件存在: $FILE_PATH"

# 获取文件大小
FILE_SIZE=$(wc -c <"$FILE_PATH")
echo "文件大小: $FILE_SIZE 字节"

# 让用户选择保存路径
if command -v zenity >/dev/null 2>&1; then
    OUTPUT_PATH=$(zenity --file-selection --save --confirm-overwrite --title="保存二进制字符串" --filename="binary_output.txt" 2>/dev/null)
    if [ $? -ne 0 ] || [ -z "$OUTPUT_PATH" ]; then
        # 如果未选择保存路径，则使用默认路径
        OUTPUT_PATH="$DEFAULT_OUTPUT_PATH"
    fi
else
    echo "请输入要保存的文件路径（留空则保存到当前目录下的binary_output.txt）:"
    read OUTPUT_PATH
    if [ -z "$OUTPUT_PATH" ]; then
        OUTPUT_PATH="$DEFAULT_OUTPUT_PATH"
    fi
fi

# 确保目录存在
mkdir -p "$(dirname "$OUTPUT_PATH")"

# 转换为二进制字符串并保存到文件
echo "正在转换为二进制字符串并保存到 $OUTPUT_PATH ..."

# 使用临时文件处理
TEMP_HEX=$(mktemp)
TEMP_BIN=$(mktemp)

# 将文件转为十六进制
xxd -p "$FILE_PATH" > "$TEMP_HEX"

# 将十六进制转为二进制并保存
while read -r line; do
    echo "$line" | while read -n2 hex; do
        if [ -n "$hex" ]; then
            printf "%08b" "0x$hex"
        fi
    done
done < "$TEMP_HEX" > "$OUTPUT_PATH"

# 显示结果
echo "转换完成，二进制字符串已保存到: $OUTPUT_PATH"
echo "文件内容预览:"
head -c 100 "$OUTPUT_PATH"
if [ $(wc -c <"$OUTPUT_PATH") -gt 100 ]; then
    echo "...（内容被截断）"
fi

# 清理临时文件
rm -f "$TEMP_HEX" "$TEMP_BIN"

exit 0
