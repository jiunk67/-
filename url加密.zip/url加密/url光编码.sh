#!/bin/bash

# =============================================
# url_encoder_tool.sh
# 一个交互式的 Shell URL 编码工具
#
# 功能：
#   1. 运行后提示输入待编码文件的完整路径
#   2. 读取该文件内容并进行 URL 编码
#   3. 提示输入保存编码结果的完整路径
#   4. 将编码结果保存到指定文件
#
# 注意：本工具仅处理文本内容，不处理二进制文件
# =============================================

# ======================
# URL 编码函数（纯 Shell 实现）
# ======================
urlencode() {
    local string="${1}"
    local length="${#string}"
    local encoded=""
    local pos char

    for (( pos=0 ; pos<length ; pos++ )); do
        char=${string:$pos:1}
        case "$char" in
            [a-zA-Z0-9.~_-]) 
                encoded+="$char" 
                ;;
            *) 
                printf -v hex '%02X' "'$char"
                encoded+="%$hex" 
                ;;
        esac
    done

    echo "$encoded"
}

# ======================
# 主程序开始
# ======================

# 检查是否提供了文件作为参数（可选，但我们用交互式，所以不依赖参数）
# 直接进入交互式提示

echo "=============================================="
echo "    🛡️  URL 编码工具（交互式文件版）"
echo "    🔐 读取文件内容，进行 URL 编码，并保存结果"
echo "=============================================="

# ------
# 步骤 1：提示输入【待编码的文件完整路径】
# ------
read -p "📂 请输入要编码的文件的完整路径（如 /home/user/input.txt）: " INPUT_FILE_PATH

# 检查文件是否存在
if [ ! -f "$INPUT_FILE_PATH" ]; then
    echo "❌ 错误：文件 '$INPUT_FILE_PATH' 不存在或不是一个普通文件."
    exit 1
fi

# 检查是否可读
if [ ! -r "$INPUT_FILE_PATH" ]; then
    echo "❌ 错误：文件 '$INPUT_FILE_PATH' 不可读，请检查权限."
    exit 1
fi

# 读取文件内容（全部读取，适合文本文件）
echo "📖 正在读取文件内容..."
FILE_CONTENT=$(cat "$INPUT_FILE_PATH" 2>/dev/null)

if [ -z "$FILE_CONTENT" ]; then
    echo "⚠️  警告：文件内容为空，或读取失败."
fi

# ------
# 步骤 2：对内容进行 URL 编码
# ------
echo "🔒 正在对内容进行 URL 编码..."
ENCODED_CONTENT=""
while IFS= read -r -n1 char; do
    if [[ "$char" =~ [a-zA-Z0-9.~_-] ]]; then
        ENCODED_CONTENT+="$char"
    else
        # 获取字符的 ASCII 码，转为16进制，格式化为 %XX
        printf -v hex '%02X' "'$char"
        ENCODED_CONTENT+="%$hex"
    fi
done <<< "$FILE_CONTENT"

# ------
# 步骤 3：提示输入【保存编码结果的完整路径】
# ------
read -p "💾 请输入编码后内容要保存到的完整路径（如 /home/user/encoded_output.txt）: " OUTPUT_FILE_PATH

# 检查输出目录是否可写（粗略判断：至少判断文件是否可被创建/覆盖）
if [ -e "$OUTPUT_FILE_PATH" ] && [ ! -w "$OUTPUT_FILE_PATH" ]; then
    echo "❌ 错误：文件 '$OUTPUT_FILE_PATH' 存在但不可写，请检查权限."
    exit 1
fi

# 尝试写入（包括创建目录权限等，简单判断）
OUTPUT_DIR=$(dirname "$OUTPUT_FILE_PATH")
if [ ! -z "$OUTPUT_DIR" ] && [ ! -w "$OUTPUT_DIR" ] && [ ! -d "$OUTPUT_DIR" ]; then
    echo "❌ 错误：目标目录 '$OUTPUT_DIR' 不可写或不存在，无法保存文件."
    exit 1
fi

# 保存编码内容到目标文件
echo "💾 正在保存编码后的内容到: $OUTPUT_FILE_PATH"
echo "$ENCODED_CONTENT" > "$OUTPUT_FILE_PATH"

if [ $? -eq 0 ]; then
    echo "✅ 编码完成！"
    echo "🔐 原始文件: $INPUT_FILE_PATH"
    echo "🔒 编码后保存至: $OUTPUT_FILE_PATH"
else
    echo "❌ 保存失败，请检查路径和权限."
    exit 1
fi

echo "=============================================="
