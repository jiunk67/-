#!/bin/bash

# =============================================
# url_decode_tool.sh
# 功能：一个交互式的 URL 解码工具（纯 Shell 实现）
#
# 支持：
#   - 手动输入或从文件读取 URL 编码内容
#   - 自动解码 %20, %E4%B8%AD 等为原始字符
#   - 显示解码结果
#   - 可选择将解码结果保存到文件
#   - 无需 python / perl / curl，纯 Bash 实现
# =============================================

# ======================
# URL 解码函数（纯 Shell 实现）
# ======================
urldecode() {
    local encoded="$1"
    local len=${#encoded}
    local i=0
    local c o
    local decoded=""

    while [ $i -lt $len ]; do
        c=${encoded:$i:1}
        if [ "$c" = "%" ]; then
            # 提取两位十六进制
            o=$(printf '%d' "'${encoded:$((i+1)):1}")
            o=$((o * 16))
            o=$((o + $(printf '%d' "'${encoded:$((i+2)):1}")))
            decoded+=$(printf "\\$(printf '%03o' "$o")")
            i=$((i + 3))
        else
            decoded+="$c"
            i=$((i + 1))
        fi
    done

    echo -n "$decoded"
}

# ======================
# 主程序
# ======================

echo "=============================================="
echo "    🧩 URL 解码工具（交互式）"
echo "    🔓 输入 URL 编码内容，自动还原原始文本"
echo "=============================================="

# 询问输入方式
echo "请选择输入方式："
echo "1) 📝 手动输入 URL 编码内容（如 %20 或 %E4%B8%AD）"
echo "2) 📂 从文件中读取 URL 编码内容"
read -p "请输入选项 [1 或 2]: " choice

INPUT_CONTENT=""

case "$choice" in
    1)
        # 手动输入
        read -p "🔤 请输入要解码的 URL 编码字符串: " INPUT_CONTENT
        ;;
    2)
        # 从文件读取
        read -p "📂 请输入包含 URL 编码内容的文件完整路径: " INPUT_FILE_PATH

        if [ ! -f "$INPUT_FILE_PATH" ]; then
            echo "❌ 错误：文件 '$INPUT_FILE_PATH' 不存在."
            exit 1
        fi

        if [ ! -r "$INPUT_FILE_PATH" ]; then
            echo "❌ 错误：文件 '$INPUT_FILE_PATH' 不可读."
            exit 1
        fi

        INPUT_CONTENT=$(cat "$INPUT_FILE_PATH" 2>/dev/null)
        if [ -z "$INPUT_CONTENT" ]; then
            echo "⚠️  警告：文件内容为空."
        fi
        ;;
    *)
        echo "❌ 无效选项，退出."
        exit 1
        ;;
esac

# 检查是否有输入内容
if [ -z "$INPUT_CONTENT" ]; then
    echo "❌ 错误：没有提供有效的 URL 编码内容."
    exit 1
fi

# 执行解码
echo "🔓 正在解码 URL 编码内容..."
DECODED_CONTENT=$(urldecode "$INPUT_CONTENT")

if [ -z "$DECODED_CONTENT" ]; then
    echo "❌ 解码失败，输入可能不是合法的 URL 编码."
    exit 1
fi

# 输出解码结果
echo ""
echo "✅ 解码完成！"
echo "🔤 原始编码内容: $INPUT_CONTENT"
echo ""
echo "🔓 解码后的内容:"
echo "-----------------------------"
echo "$DECODED_CONTENT"
echo "-----------------------------"

# 询问是否保存到文件
read -p "💾 是否要将解码结果保存到文件？[y/N]: " save_choice

if [[ "$save_choice" =~ ^[Yy]$ ]]; then
    read -p "📤 请输入保存的完整文件路径（如 ~/decoded_output.txt）: " OUTPUT_FILE_PATH

    # 检查目录是否可写
    OUTPUT_DIR=$(dirname "$OUTPUT_FILE_PATH")
    if [ -n "$OUTPUT_DIR" ] && [ ! -w "$OUTPUT_DIR" ] && [ ! -d "$OUTPUT_DIR" ]; then
        echo "❌ 错误：目标目录不可写或不存在."
        exit 1
    fi

    echo "$DECODED_CONTENT" > "$OUTPUT_FILE_PATH"
    if [ $? -eq 0 ]; then
        echo "✅ 解码内容已保存到: $OUTPUT_FILE_PATH"
    else
        echo "❌ 保存失败，请检查路径或权限."
        exit 1
    fi
fi

echo "=============================================="
