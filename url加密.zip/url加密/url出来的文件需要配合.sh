#!/system/bin/sh

# =============================================
# 一体式脚本加密自解密工具 v9.2
# 功能：加密脚本内容并生成自解密执行脚本
# 特点：完全保持原始脚本的执行效果和格式
# =============================================

# 工具信息
TOOL_NAME="一体式脚本加密自解密工具"
VERSION="9.2"
SCRIPT_TYPE="Root工具脚本"

# 存储配置
STORAGE_DIR="/storage/emulated/0/script_encrypt_files"
ENCRYPTED_SCRIPT="$STORAGE_DIR/encrypted_root_tool_final.sh"

# 创建存储目录
create_storage_dir() {
    if [ ! -d "$STORAGE_DIR" ]; then
        mkdir -p "$STORAGE_DIR"
        if [ $? -ne 0 ]; then
            echo "错误：无法创建存储目录 $STORAGE_DIR"
            echo "请确保有存储写入权限"
            exit 1
        fi
    fi
}

# URL编码函数
url_encode() {
    echo "$1" | awk -v ORS="" '
    BEGIN {
        safe_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~"
    }
    {
        for (i = 1; i <= length($0); i++) {
            c = substr($0, i, 1)
            if (c == "\n") {
                printf "\n"
            }
            else if (c == "\t") {
                printf "\t"
            }
            else if (c == " ") {
                printf "+"
            }
            else if (index(safe_chars, c) > 0) {
                printf c
            }
            else {
                printf "%%%02X", sprintf("%d", index(" !\"#$%&'\''()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~", c))
            }
        }
    }'
}

# URL解码函数
url_decode() {
    echo "$1" | awk -v ORS="" '
    BEGIN {
    }
    {
        len = length($0)
        i = 1
        while (i <= len) {
            c = substr($0, i, 1)
            if (c == "%") {
                if (i + 2 <= len) {
                    hex = substr($0, i + 1, 2)
                    printf "%c", strtonum("0x" hex)
                    i = i + 3
                } else {
                    printf c
                    i = i + 1
                }
            }
            else if (c == "+") {
                printf " "
                i = i + 1
            }
            else {
                printf c
                i = i + 1
            }
        }
    }'
}

# 生成自解密执行脚本
generate_self_decoding_script() {
    ENCODED_CONTENT="$1"
    
    cat > "$ENCRYPTED_SCRIPT" << EOF
#!/system/bin/sh

# =========================================
# 自解密执行脚本 - 由 $TOOL_NAME 生成
# 版本: $VERSION
# =========================================

# URL解码核心函数
url_decode() {
    echo "\$1" | awk -v ORS="" '\''
    BEGIN {
    }
    {
        len = length(\$0)
        i = 1
        while (i <= len) {
            c = substr(\$0, i, 1)
            if (c == "%") {
                if (i + 2 <= len) {
                    hex = substr(\$0, i + 1, 2)
                    printf "%c", strtonum("0x" hex)
                    i = i + 3
                } else {
                    printf c
                    i = i + 1
                }
            }
            else if (c == "+") {
                printf " "
                i = i + 1
            }
            else {
                printf c
                i = i + 1
            }
        }
    }\'''
}

# 显示执行信息
show_execution_info() {
    echo ""
    echo "╔══════════════════════════════════════╗"
    echo "║           🚀 自解码执行器            ║"
    echo "║                                      ║"
    echo "║  工具: $TOOL_NAME                     ║"
    echo "║  版本: $VERSION                        ║"
    echo "║  文件: \$(basename "\$0")              ║"
    echo "║                                      ║"
    echo "╠══════════════════════════════════════╣"
    echo "║  📌 正在解码并执行原始脚本内容...    ║"
    echo "╚══════════════════════════════════════╝"
    echo ""
}

# 主执行函数
main_execution() {
    show_execution_info
    
    # 解码嵌入的URL编码内容
    DECODED_SCRIPT=\$(url_decode "$ENCODED_CONTENT")
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "🔍 解码完成！准备执行原始脚本内容..."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    # 创建临时文件执行脚本
    TEMP_FILE=\$(mktemp)
    echo "\$DECODED_SCRIPT" > "\$TEMP_FILE"
    chmod +x "\$TEMP_FILE"
    . "\$TEMP_FILE"
    rm -f "\$TEMP_FILE"
    
    echo ""
    echo "✅ 原始脚本执行完成！"
    echo "📅 时间: \$(date)"
    echo ""
}

# 脚本入口
main_execution

exit 0
EOF
    
    chmod +x "$ENCRYPTED_SCRIPT"
}

# 主程序
main() {
    create_storage_dir
    
    echo ""
    echo "========================================"
    echo "  $TOOL_NAME"
    echo "  版本: $VERSION"
    echo "========================================"
    echo ""
    
    echo "📝 请输入您的脚本内容（支持多行输入）："
    echo "   （输入完成后请单独输入一行：__END__ 来结束输入）"
    echo ""
    
    SCRIPT_CONTENT=""
    while IFS= read -r line; do
        if [ "$line" = "__END__" ]; then
            break
        fi
        SCRIPT_CONTENT="$SCRIPT_CONTENT$line\n"
    done
    
    if [ -z "$SCRIPT_CONTENT" ] || [ "$SCRIPT_CONTENT" = "\n" ]; then
        echo "❌ 错误：没有输入任何脚本内容"
        exit 1
    fi
    
    SCRIPT_CONTENT=$(echo -e "$SCRIPT_CONTENT" | sed '$d')
    
    echo ""
    echo "🔒 正在进行脚本内容编码..."
    ENCODED_CONTENT=$(url_encode "$SCRIPT_CONTENT")
    
    generate_self_decoding_script "$ENCODED_CONTENT"
    
    echo ""
    echo "✅ 编码完成！"
    echo ""
    echo "📁 加密后的自解密执行脚本已保存到："
    echo "   $ENCRYPTED_SCRIPT"
    echo ""
    echo "🚀 使用方法："
    echo "   直接执行生成的脚本文件："
    echo "   sh $ENCRYPTED_SCRIPT"
    echo "   或者添加执行权限后直接运行："
    echo "   chmod +x $ENCRYPTED_SCRIPT && $ENCRYPTED_SCRIPT"
    echo ""
}

main
