#!/bin/bash
# 自解码执行器
# 工具：一体式脚本加密自解密工具
# 版本：9.2
# 文件：encrypted_root_tool_final.sh

# 函数：生成SHA-256哈希
generate_sha256() {
    local input="$1"
    echo -n "$input" | sha256sum | awk '{print $1}'
}

# 函数：验证SHA-256哈希
verify_sha256() {
    local input="$1"
    local hash_to_verify="$2"
    local computed_hash=$(generate_sha256 "$input")
    
    if [ "$computed_hash" == "$hash_to_verify" ]; then
        echo "验证成功: 哈希匹配。"
    else
        echo "验证失败: 哈希不匹配。"
    fi
}

# 主菜单
main_menu() {
    clear
    echo "============================================="
    echo "   自解码执行器 - SHA-256哈希工具            "
    echo "   工具版本: 9.2                               "
    echo "============================================="
    echo "1. 生成SHA-256哈希"
    echo "2. 验证SHA-256哈希"
    echo "3. 退出"
    echo "============================================="
    read -p "请选择操作 [1-3]: " choice
    case $choice in
        1)
            read -p "请输入要哈希的字符串: " original_string
            hashed=$(generate_sha256 "$original_string")
            echo -e "\n原始字符串: $original_string"
            echo "SHA-256 哈希: $hashed"
            ;;
        2)
            read -p "请输入要验证的原始字符串: " original_string
            read -p "请输入要验证的SHA-256哈希: " hash_to_verify
            verify_sha256 "$original_string" "$hash_to_verify"
            ;;
        3)
            echo "退出程序。"
            exit 0
            ;;
        *)
            echo "无效的选择，请重新输入。"
            sleep 2
            main_menu
            ;;
    esac
}

# 运行主菜单
main_menu
